"""
Step 11: TTS 语音播报 / 页面展示结果
支持: gTTS / pyttsx3 / 百度 TTS / Mock 模式
"""
import os
import time
import hashlib
from abc import ABC, abstractmethod
from typing import Optional

from modules.logger import setup_logger

logger = setup_logger("tts")


# ─────────────────────────────────────────────
# 抽象基类
# ─────────────────────────────────────────────
class TTSBase(ABC):
    @abstractmethod
    def synthesize(self, text: str, output_path: str) -> str:
        """合成语音，返回音频文件路径"""
        ...

    @abstractmethod
    def speak(self, text: str) -> None:
        """直接播放语音"""
        ...


# ─────────────────────────────────────────────
# gTTS（Google Text-to-Speech）
# ─────────────────────────────────────────────
class GTTSEngine(TTSBase):
    def __init__(self, language: str = "zh", speed: float = 1.0):
        try:
            from gtts import gTTS
            self.gTTS = gTTS
            self.language = language
            self.slow = speed < 0.8
            logger.info(f"gTTS 引擎初始化: lang={language}")
        except ImportError:
            raise RuntimeError("请安装 gTTS: pip install gTTS")

    def synthesize(self, text: str, output_path: str) -> str:
        tts = self.gTTS(text=text, lang=self.language, slow=self.slow)
        tts.save(output_path)
        logger.info(f"[gTTS] 语音已保存: {output_path}")
        return output_path

    def speak(self, text: str) -> None:
        tmp_path = f"/tmp/tts_{int(time.time())}.mp3"
        self.synthesize(text, tmp_path)
        try:
            import pygame
            pygame.mixer.init()
            pygame.mixer.music.load(tmp_path)
            pygame.mixer.music.play()
            while pygame.mixer.music.get_busy():
                time.sleep(0.1)
        except ImportError:
            try:
                os.system(f"mpg123 {tmp_path} 2>/dev/null || afplay {tmp_path} 2>/dev/null || aplay {tmp_path} 2>/dev/null")
            except Exception:
                logger.warning("无法播放音频，请手动播放: " + tmp_path)
        finally:
            try:
                os.unlink(tmp_path)
            except Exception:
                pass


# ─────────────────────────────────────────────
# pyttsx3（离线 TTS）
# ─────────────────────────────────────────────
class Pyttsx3Engine(TTSBase):
    def __init__(self, speed: float = 1.0, volume: float = 0.9):
        try:
            import pyttsx3
            self.engine = pyttsx3.init()
            # 设置语速（默认200词/分钟）
            rate = self.engine.getProperty("rate")
            self.engine.setProperty("rate", int(rate * speed))
            self.engine.setProperty("volume", volume)
            logger.info("pyttsx3 引擎初始化完成")
        except ImportError:
            raise RuntimeError("请安装 pyttsx3: pip install pyttsx3")

    def synthesize(self, text: str, output_path: str) -> str:
        self.engine.save_to_file(text, output_path)
        self.engine.runAndWait()
        logger.info(f"[pyttsx3] 语音已保存: {output_path}")
        return output_path

    def speak(self, text: str) -> None:
        self.engine.say(text)
        self.engine.runAndWait()


# ─────────────────────────────────────────────
# 百度 TTS
# ─────────────────────────────────────────────
class BaiduTTSEngine(TTSBase):
    def __init__(self, app_id: str, api_key: str, secret_key: str,
                 speed: int = 5, pitch: int = 5, volume: int = 5, person: int = 0):
        try:
            from aip import AipSpeech
            self.client = AipSpeech(app_id, api_key, secret_key)
            self.options = {
                "spd": speed,    # 语速 0-9
                "pit": pitch,    # 音调 0-9
                "vol": volume,   # 音量 0-15
                "per": person,   # 发音人 0-女 1-男 3-情感合成-度逍遥 4-情感合成-度丫丫
                "aue": 3,        # 格式 3-mp3
            }
            logger.info("百度 TTS 引擎初始化完成")
        except ImportError:
            raise RuntimeError("请安装 baidu-aip: pip install baidu-aip")

    def synthesize(self, text: str, output_path: str) -> str:
        result = self.client.synthesis(text, "zh", 1, self.options)
        if not isinstance(result, dict):
            with open(output_path, "wb") as f:
                f.write(result)
            return output_path
        raise RuntimeError(f"百度 TTS 错误: {result}")

    def speak(self, text: str) -> None:
        tmp_path = f"/tmp/tts_baidu_{int(time.time())}.mp3"
        self.synthesize(text, tmp_path)
        os.system(f"mpg123 {tmp_path} 2>/dev/null || afplay {tmp_path} 2>/dev/null")
        try:
            os.unlink(tmp_path)
        except Exception:
            pass


# ─────────────────────────────────────────────
# Mock TTS（纯文本输出，测试用）
# ─────────────────────────────────────────────
class MockTTSEngine(TTSBase):
    def synthesize(self, text: str, output_path: str) -> str:
        logger.info(f"[Mock TTS] 模拟合成: 「{text[:60]}...」")
        # 写一个占位文件
        with open(output_path, "wb") as f:
            f.write(b"\x00" * 1024)
        return output_path

    def speak(self, text: str) -> None:
        print(f"\n🔊 [TTS 播报]: {text}\n")
        logger.info(f"[Mock TTS] 播报: 「{text}」")


# ─────────────────────────────────────────────
# TTS 管理器（Step 11 门面）
# ─────────────────────────────────────────────
class TTSManager:
    """
    TTS 管理器
    - 支持语音缓存（相同文本不重复合成）
    - 自动降级
    """

    def __init__(self, config):
        self.config = config
        self.output_dir = config.tts.output_dir
        os.makedirs(self.output_dir, exist_ok=True)
        self.engine = self._build_engine(config.tts)
        self._cache: dict = {}

    def _build_engine(self, cfg) -> TTSBase:
        provider = cfg.provider.lower()
        logger.info(f"TTS 引擎: {provider}")
        try:
            if provider == "gtts":
                return GTTSEngine(language=cfg.language, speed=cfg.speed)
            elif provider == "pyttsx3":
                return Pyttsx3Engine(speed=cfg.speed, volume=cfg.volume)
            elif provider == "baidu":
                from config import config as app_config
                return BaiduTTSEngine(
                    app_id=app_config.asr.baidu_app_id,
                    api_key=app_config.asr.baidu_api_key,
                    secret_key=app_config.asr.baidu_secret_key,
                )
        except Exception as e:
            logger.warning(f"TTS 引擎 {provider} 初始化失败: {e}，使用 Mock")
        return MockTTSEngine()

    def _get_cache_path(self, text: str) -> str:
        """根据文本生成缓存文件路径"""
        key = hashlib.md5(text.encode("utf-8")).hexdigest()[:12]
        ext = "mp3" if self.config.tts.provider == "gtts" else "wav"
        return os.path.join(self.output_dir, f"tts_{key}.{ext}")

    def speak(self, text: str, use_cache: bool = True):
        """
        Step 11: TTS 语音播报
        """
        logger.info(f"Step 11: TTS 播报 → 「{text[:60]}」")
        print(f"\n🔊 助手回复: {text}\n")

        try:
            self.engine.speak(text)
        except Exception as e:
            logger.error(f"TTS 播放失败: {e}")
            print(f"📝 [文字展示]: {text}")

    def synthesize_to_file(self, text: str, output_path: Optional[str] = None) -> str:
        """合成语音到文件"""
        if not output_path:
            output_path = self._get_cache_path(text)

        # 检查缓存
        if os.path.exists(output_path):
            logger.debug(f"使用缓存音频: {output_path}")
            return output_path

        try:
            return self.engine.synthesize(text, output_path)
        except Exception as e:
            logger.error(f"TTS 合成失败: {e}")
            return ""

    def synthesize_to_bytes(self, text: str) -> bytes:
        """合成语音到字节流（用于 API 响应）"""
        path = self.synthesize_to_file(text)
        if path and os.path.exists(path):
            with open(path, "rb") as f:
                return f.read()
        return b""
