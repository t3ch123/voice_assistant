"""
上下文管理模块（Step 7-多轮对话: 结合上下文继续处理）
维护对话历史、会话状态
"""
import json
import time
import uuid
from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict, Any
from enum import Enum

from modules.logger import setup_logger

logger = setup_logger("context")


class MessageRole(str, Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


@dataclass
class Message:
    role: MessageRole
    content: str
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "role": self.role.value if isinstance(self.role, MessageRole) else self.role,
            "content": self.content,
        }


@dataclass
class ToolCall:
    """工具调用记录"""
    tool_name: str
    tool_input: Dict[str, Any]
    tool_result: Any
    timestamp: float = field(default_factory=time.time)
    duration_ms: float = 0.0
    success: bool = True
    error: Optional[str] = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class SessionState:
    """单次会话状态"""
    session_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    created_at: float = field(default_factory=time.time)
    user_id: str = "default_user"

    # 对话历史
    messages: List[Message] = field(default_factory=list)
    # 工具调用历史
    tool_calls: List[ToolCall] = field(default_factory=list)
    # 当前任务类型
    current_task_type: Optional[str] = None
    # 自定义数据（可存储任务相关信息）
    data: Dict[str, Any] = field(default_factory=dict)

    def add_message(self, role: MessageRole, content: str, **metadata):
        msg = Message(role=role, content=content, metadata=metadata)
        self.messages.append(msg)
        logger.debug(f"[Session {self.session_id}] {role.value}: {content[:80]}...")

    def add_tool_call(self, tool_call: ToolCall):
        self.tool_calls.append(tool_call)

    def get_messages_for_llm(self, system_prompt: str = "", max_turns: int = 20) -> List[dict]:
        """
        返回适合 LLM API 格式的消息列表
        包含系统提示 + 最近 N 轮对话
        """
        result = []
        if system_prompt:
            result.append({"role": "system", "content": system_prompt})

        # 只取最近 max_turns 轮
        recent = self.messages[-max_turns * 2:]
        result.extend([m.to_dict() for m in recent])
        return result

    def get_summary(self) -> dict:
        return {
            "session_id": self.session_id,
            "user_id": self.user_id,
            "message_count": len(self.messages),
            "tool_call_count": len(self.tool_calls),
            "current_task_type": self.current_task_type,
            "duration_seconds": round(time.time() - self.created_at, 1),
        }

    def clear_history(self):
        self.messages.clear()
        self.tool_calls.clear()
        self.data.clear()
        logger.info(f"[Session {self.session_id}] 上下文已清空")


class ContextManager:
    """
    多会话上下文管理器
    - 创建/获取/删除会话
    - 自动过期清理
    """

    def __init__(self, max_turns: int = 20, session_ttl: int = 3600):
        self.max_turns = max_turns
        self.session_ttl = session_ttl  # 会话有效期（秒）
        self._sessions: Dict[str, SessionState] = {}
        logger.info(f"ContextManager 初始化: max_turns={max_turns}, session_ttl={session_ttl}s")

    def get_or_create_session(self, session_id: Optional[str] = None, user_id: str = "default") -> SessionState:
        """获取或新建会话"""
        # 清理过期会话
        self._cleanup_expired()

        if session_id and session_id in self._sessions:
            session = self._sessions[session_id]
            logger.debug(f"恢复会话: {session_id} (共 {len(session.messages)} 条消息)")
            return session

        # 新建
        session = SessionState(user_id=user_id)
        if session_id:
            session.session_id = session_id
        self._sessions[session.session_id] = session
        logger.info(f"新建会话: {session.session_id}")
        return session

    def get_session(self, session_id: str) -> Optional[SessionState]:
        return self._sessions.get(session_id)

    def delete_session(self, session_id: str):
        if session_id in self._sessions:
            del self._sessions[session_id]
            logger.info(f"删除会话: {session_id}")

    def list_sessions(self) -> List[dict]:
        return [s.get_summary() for s in self._sessions.values()]

    def _cleanup_expired(self):
        now = time.time()
        expired = [
            sid for sid, s in self._sessions.items()
            if now - s.created_at > self.session_ttl
        ]
        for sid in expired:
            del self._sessions[sid]
            logger.info(f"过期会话已清理: {sid}")

    def export_session(self, session_id: str) -> Optional[str]:
        """导出会话为 JSON"""
        session = self.get_session(session_id)
        if not session:
            return None
        data = {
            "session_id": session.session_id,
            "user_id": session.user_id,
            "created_at": session.created_at,
            "messages": [m.to_dict() for m in session.messages],
            "tool_calls": [tc.to_dict() for tc in session.tool_calls],
        }
        return json.dumps(data, ensure_ascii=False, indent=2)
