"""
大语言模型客户端（Step 6: 大模型意图识别 / Step 9: 大模型生成自然语言回复）
支持: OpenAI / Anthropic / 智谱 / Mock
"""
import json
import time
from abc import ABC, abstractmethod
from typing import List, Dict, Optional, Any, Generator

from modules.logger import setup_logger

logger = setup_logger("llm")


# ─────────────────────────────────────────────
# 抽象基类
# ─────────────────────────────────────────────
class LLMBase(ABC):
    @abstractmethod
    def chat(self, messages: List[Dict], **kwargs) -> str: ...

    @abstractmethod
    def chat_stream(self, messages: List[Dict], **kwargs) -> Generator[str, None, None]: ...


# ─────────────────────────────────────────────
# OpenAI 客户端
# ─────────────────────────────────────────────
class OpenAIClient(LLMBase):
    def __init__(self, api_key: str, model: str = "gpt-4o-mini", api_base: str = None,
                 max_tokens: int = 2048, temperature: float = 0.7, timeout: int = 30):
        try:
            from openai import OpenAI
            self.client = OpenAI(api_key=api_key, base_url=api_base, timeout=timeout)
            self.model = model
            self.max_tokens = max_tokens
            self.temperature = temperature
            logger.info(f"OpenAI 客户端初始化: model={model}")
        except ImportError:
            raise RuntimeError("请安装 openai: pip install openai")

    def chat(self, messages: List[Dict], **kwargs) -> str:
        try:
            resp = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=kwargs.get("max_tokens", self.max_tokens),
                temperature=kwargs.get("temperature", self.temperature),
            )
            content = resp.choices[0].message.content or ""
            logger.debug(f"[OpenAI] 回复 ({len(content)} chars)")
            return content
        except Exception as e:
            logger.error(f"[OpenAI] 请求失败: {e}")
            raise

    def chat_stream(self, messages: List[Dict], **kwargs) -> Generator[str, None, None]:
        stream = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            stream=True,
        )
        for chunk in stream:
            delta = chunk.choices[0].delta.content
            if delta:
                yield delta


# ─────────────────────────────────────────────
# Anthropic 客户端
# ─────────────────────────────────────────────
class AnthropicClient(LLMBase):
    def __init__(self, api_key: str, model: str = "claude-3-haiku-20240307",
                 max_tokens: int = 2048, temperature: float = 0.7):
        try:
            import anthropic
            self.client = anthropic.Anthropic(api_key=api_key)
            self.model = model
            self.max_tokens = max_tokens
            self.temperature = temperature
            logger.info(f"Anthropic 客户端初始化: model={model}")
        except ImportError:
            raise RuntimeError("请安装 anthropic: pip install anthropic")

    def chat(self, messages: List[Dict], **kwargs) -> str:
        system_msg = ""
        user_msgs = []
        for m in messages:
            if m["role"] == "system":
                system_msg = m["content"]
            else:
                user_msgs.append(m)
        try:
            resp = self.client.messages.create(
                model=self.model,
                max_tokens=self.max_tokens,
                system=system_msg,
                messages=user_msgs,
            )
            return resp.content[0].text
        except Exception as e:
            logger.error(f"[Anthropic] 请求失败: {e}")
            raise

    def chat_stream(self, messages: List[Dict], **kwargs) -> Generator[str, None, None]:
        system_msg = next((m["content"] for m in messages if m["role"] == "system"), "")
        user_msgs = [m for m in messages if m["role"] != "system"]
        with self.client.messages.stream(
            model=self.model,
            max_tokens=self.max_tokens,
            system=system_msg,
            messages=user_msgs,
        ) as stream:
            for text in stream.text_stream:
                yield text


# ─────────────────────────────────────────────
# 智谱 AI 客户端
# ─────────────────────────────────────────────
class ZhipuClient(LLMBase):
    def __init__(self, api_key: str, model: str = "glm-4-flash",
                 max_tokens: int = 2048, temperature: float = 0.7):
        try:
            from zhipuai import ZhipuAI
            self.client = ZhipuAI(api_key=api_key)
            self.model = model
            self.max_tokens = max_tokens
            self.temperature = temperature
            logger.info(f"智谱 AI 客户端初始化: model={model}")
        except ImportError:
            raise RuntimeError("请安装 zhipuai: pip install zhipuai")

    def chat(self, messages: List[Dict], **kwargs) -> str:
        resp = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            max_tokens=self.max_tokens,
            temperature=self.temperature,
        )
        return resp.choices[0].message.content

    def chat_stream(self, messages: List[Dict], **kwargs) -> Generator[str, None, None]:
        stream = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            stream=True,
        )
        for chunk in stream:
            if chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content


# ─────────────────────────────────────────────
# Mock LLM（无需 API Key，用于测试）
# ─────────────────────────────────────────────
class MockLLMClient(LLMBase):
    """
    模拟 LLM 响应，用于无 API Key 的本地测试
    根据用户输入生成符合逻辑的模拟回复
    """

    INTENT_RESPONSES = {
        "天气": {
            "intent": "query_weather",
            "task_type": "tool_call",
            "entities": {"location": "北京", "date": "今天"},
            "confidence": 0.95,
            "description": "用户想查询天气信息"
        },
        "闹钟": {
            "intent": "set_alarm",
            "task_type": "tool_call",
            "entities": {"time": "明天早上8点"},
            "confidence": 0.92,
            "description": "用户想设置闹钟"
        },
        "邮件": {
            "intent": "send_email",
            "task_type": "complex_task",
            "entities": {"recipient": "张三"},
            "confidence": 0.88,
            "description": "用户想发送邮件"
        },
        "计算": {
            "intent": "calculate",
            "task_type": "tool_call",
            "entities": {"expression": "1234 * 5678"},
            "confidence": 0.99,
            "description": "用户想进行数学计算"
        },
        "翻译": {
            "intent": "translate",
            "task_type": "tool_call",
            "entities": {"text": "人工智能改变世界", "target_lang": "英文"},
            "confidence": 0.97,
            "description": "用户想翻译文本"
        },
        "搜索": {
            "intent": "web_search",
            "task_type": "tool_call",
            "entities": {"query": "最新AI新闻"},
            "confidence": 0.90,
            "description": "用户想搜索信息"
        },
        "提醒": {
            "intent": "set_reminder",
            "task_type": "tool_call",
            "entities": {"content": "明天的会议", "time": "明天"},
            "confidence": 0.91,
            "description": "用户想设置提醒"
        },
    }

    ANSWER_TEMPLATES = {
        "query_weather": "好的，我来为您查询天气信息。根据最新气象数据，{location}今天天气晴朗，气温18-26°C，空气质量良好，适合外出活动。",
        "set_alarm": "闹钟已成功设置！我将在{time}提醒您。请确保手机不要静音哦。",
        "send_email": "邮件已准备好发送给{recipient}。请问您想在邮件中写什么内容？",
        "calculate": "计算结果：{expression} = {result}",
        "translate": "翻译结果：「{text}」的英文是：\"Artificial intelligence is changing the world\"",
        "web_search": "我已为您搜索「{query}」，以下是相关内容摘要：1. 大型语言模型持续进化；2. AI在医疗领域取得突破；3. 自动驾驶技术趋于成熟。",
        "set_reminder": "提醒已设置！我会在{time}提醒您：{content}。",
        "default": "好的，我已理解您的需求。让我来为您处理这个请求。您还有什么需要我帮助的吗？",
    }

    def chat(self, messages: List[Dict], **kwargs) -> str:
        user_content = ""
        for m in reversed(messages):
            if m["role"] == "user":
                user_content = m["content"]
                break

        # 判断是意图识别还是自然语言回复：根据 prompt 的具体内容区分
        is_intent_prompt = (
            "严格以 JSON 格式返回" in user_content
            or "intent" in user_content and "task_type" in user_content and "entities" in user_content and "confidence" in user_content
        )
        if is_intent_prompt:
            # 提取实际用户输入（意图识别 prompt 格式：用户输入: "xxx"）
            import re as _re
            m = _re.search(r'用户输入[:：]\s*["「](.+?)["」]', user_content)
            actual_input = m.group(1) if m else user_content
            return self._mock_intent(actual_input)
        return self._mock_answer(user_content)

    def _mock_intent(self, text: str) -> str:
        for keyword, data in self.INTENT_RESPONSES.items():
            if keyword in text:
                return json.dumps(data, ensure_ascii=False)
        return json.dumps({
            "intent": "general_qa",
            "task_type": "simple_qa",
            "entities": {},
            "confidence": 0.75,
            "description": "用户提出了一个普通问题"
        }, ensure_ascii=False)

    def _mock_answer(self, text: str) -> str:
        for keyword, data in self.INTENT_RESPONSES.items():
            if keyword in text:
                template = self.ANSWER_TEMPLATES.get(data["intent"], self.ANSWER_TEMPLATES["default"])
                entities = data.get("entities", {})
                try:
                    if data["intent"] == "calculate":
                        expr = entities.get("expression", "1234 * 5678")
                        result = eval(expr.replace("乘以", "*").replace("×", "*"))
                        return template.format(expression=expr, result=result)
                    return template.format(**entities)
                except Exception:
                    return template
        return f"您好！我已收到您的消息：「{text}」。这是一个普通问题，根据我的知识库，这个问题的答案需要更多上下文才能精确回答。请问您还有其他需要帮助的吗？"

    def chat_stream(self, messages: List[Dict], **kwargs) -> Generator[str, None, None]:
        response = self.chat(messages, **kwargs)
        for char in response:
            time.sleep(0.02)
            yield char


# ─────────────────────────────────────────────
# LLM 工厂
# ─────────────────────────────────────────────
class LLMManager:
    """LLM 统一入口"""

    def __init__(self, config):
        self.config = config
        self.client = self._build_client(config.llm)

    def _build_client(self, cfg) -> LLMBase:
        provider = cfg.provider.lower()
        logger.info(f"LLM 引擎: {provider}")
        if provider == "openai" and cfg.api_key:
            return OpenAIClient(
                api_key=cfg.api_key, model=cfg.model,
                api_base=cfg.api_base, max_tokens=cfg.max_tokens,
                temperature=cfg.temperature, timeout=cfg.timeout,
            )
        elif provider == "anthropic" and cfg.anthropic_api_key:
            return AnthropicClient(
                api_key=cfg.anthropic_api_key,
                model=cfg.anthropic_model,
                max_tokens=cfg.max_tokens,
            )
        elif provider == "zhipu" and cfg.zhipu_api_key:
            return ZhipuClient(
                api_key=cfg.zhipu_api_key,
                model=cfg.zhipu_model,
                max_tokens=cfg.max_tokens,
            )
        else:
            logger.info("使用 Mock LLM（未配置 API Key）")
            return MockLLMClient()

    def chat(self, messages: List[Dict], **kwargs) -> str:
        return self.client.chat(messages, **kwargs)

    def chat_stream(self, messages: List[Dict], **kwargs) -> Generator[str, None, None]:
        return self.client.chat_stream(messages, **kwargs)
