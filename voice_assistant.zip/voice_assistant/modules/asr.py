"""
Step 2 & 3: 手机端唤醒与录音 + ASR 语音转文字
支持: Google STT / OpenAI Whisper (本地) / 百度 ASR / Mock 模式
"""
import io
import os
import time
import wave
import struct
import threading
from abc import ABC, abstractmethod
from typing import Optional, Callable

from modules.logger import setup_logger

logger = setup_logger("asr")


# ─────────────────────────────────────────────
# 抽象基类
# ─────────────────────────────────────────────
class ASRBase(ABC):
    """ASR 抽象基类"""

    @abstractmethod
    def recognize(self, audio_data: bytes, sample_rate: int = 16000) -> str:
        """将音频字节流转为文字"""
        ...

    @abstractmethod
    def recognize_file(self, file_path: str) -> str:
        """从文件识别"""
        ...


# ─────────────────────────────────────────────
# Google STT（需要 speech_recognition 库）
# ─────────────────────────────────────────────
class GoogleASR(ASRBase):
    def __init__(self, language: str = "zh-CN"):
        self.language = language
        try:
            import speech_recognition as sr
            self.recognizer = sr.Recognizer()
            self.sr = sr
            logger.info("Google ASR 初始化成功")
        except ImportError:
            raise RuntimeError("请安装 SpeechRecognition: pip install SpeechRecognition")

    def recognize(self, audio_data: bytes, sample_rate: int = 16000) -> str:
        audio = self.sr.AudioData(audio_data, sample_rate, 2)
        try:
            text = self.recognizer.recognize_google(audio, language=self.language)
            logger.info(f"[Google ASR] 识别结果: {text}")
            return text
        except self.sr.UnknownValueError:
            logger.warning("[Google ASR] 无法识别音频")
            return ""
        except self.sr.RequestError as e:
            logger.error(f"[Google ASR] 请求失败: {e}")
            return ""

    def recognize_file(self, file_path: str) -> str:
        with self.sr.AudioFile(file_path) as source:
            audio = self.recognizer.record(source)
        try:
            return self.recognizer.recognize_google(audio, language=self.language)
        except Exception as e:
            logger.error(f"[Google ASR] 文件识别失败: {e}")
            return ""


# ─────────────────────────────────────────────
# Whisper 本地模型
# ─────────────────────────────────────────────
class WhisperASR(ASRBase):
    def __init__(self, model_name: str = "base", language: str = "zh"):
        try:
            import whisper
            import tempfile
            self.whisper = whisper
            self.tempfile = tempfile
            self.model = whisper.load_model(model_name)
            self.language = language
            logger.info(f"Whisper ({model_name}) 初始化成功")
        except ImportError:
            raise RuntimeError("请安装 openai-whisper: pip install openai-whisper")

    def recognize(self, audio_data: bytes, sample_rate: int = 16000) -> str:
        with self.tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            _write_wav(tmp.name, audio_data, sample_rate)
            result = self.model.transcribe(tmp.name, language=self.language)
            text = result.get("text", "").strip()
            logger.info(f"[Whisper] 识别结果: {text}")
            os.unlink(tmp.name)
            return text

    def recognize_file(self, file_path: str) -> str:
        result = self.model.transcribe(file_path, language=self.language)
        return result.get("text", "").strip()


# ─────────────────────────────────────────────
# 百度 ASR
# ─────────────────────────────────────────────
class BaiduASR(ASRBase):
    def __init__(self, app_id: str, api_key: str, secret_key: str):
        try:
            from aip import AipSpeech
            self.client = AipSpeech(app_id, api_key, secret_key)
            logger.info("百度 ASR 初始化成功")
        except ImportError:
            raise RuntimeError("请安装 baidu-aip: pip install baidu-aip")

    def recognize(self, audio_data: bytes, sample_rate: int = 16000) -> str:
        result = self.client.asr(audio_data, "wav", sample_rate, {"lan": "zh"})
        if result.get("err_no") == 0:
            text = "".join(result.get("result", []))
            logger.info(f"[百度 ASR] 识别结果: {text}")
            return text
        logger.error(f"[百度 ASR] 错误: {result}")
        return ""

    def recognize_file(self, file_path: str) -> str:
        with open(file_path, "rb") as f:
            return self.recognize(f.read())


# ─────────────────────────────────────────────
# Mock ASR（测试用，无需麦克风/网络）
# ─────────────────────────────────────────────
class MockASR(ASRBase):
    MOCK_INPUTS = [
        "今天天气怎么样",
        "帮我查一下北京的天气",
        "设置一个明天早上8点的闹钟",
        "帮我发送一封邮件给张三",
        "计算1234乘以5678等于多少",
        "翻译：人工智能改变世界",
        "帮我搜索一下最新的AI新闻",
        "把明天的会议提醒我",
    ]
    _idx = 0

    def recognize(self, audio_data: bytes, sample_rate: int = 16000) -> str:
        text = self.MOCK_INPUTS[MockASR._idx % len(self.MOCK_INPUTS)]
        MockASR._idx += 1
        logger.info(f"[Mock ASR] 模拟输入: {text}")
        return text

    def recognize_file(self, file_path: str) -> str:
        return self.recognize(b"")


# ─────────────────────────────────────────────
# 录音器（Step 2: 手机端唤醒与录音）
# ─────────────────────────────────────────────
class AudioRecorder:
    """
    麦克风录音器
    - 按键触发 / 静音自动停止
    - 支持唤醒词检测（可选）
    """

    def __init__(
        self,
        sample_rate: int = 16000,
        channels: int = 1,
        chunk_size: int = 1024,
        silence_threshold: int = 500,
        max_seconds: int = 30,
        energy_threshold: int = 300,
    ):
        self.sample_rate = sample_rate
        self.channels = channels
        self.chunk_size = chunk_size
        self.silence_threshold = silence_threshold  # ms
        self.max_seconds = max_seconds
        self.energy_threshold = energy_threshold
        self._recording = False
        self._frames = []

    def record(self, callback: Optional[Callable[[bytes], None]] = None) -> bytes:
        """
        开始录音，返回 PCM 字节流
        callback: 录音结束后的回调函数
        """
        try:
            import pyaudio
        except ImportError:
            logger.warning("pyaudio 未安装，使用模拟录音（2秒静音）")
            time.sleep(2)
            return b"\x00" * self.sample_rate * 2 * 2  # 2秒空音频

        pa = pyaudio.PyAudio()
        stream = pa.open(
            format=pyaudio.paInt16,
            channels=self.channels,
            rate=self.sample_rate,
            input=True,
            frames_per_buffer=self.chunk_size,
        )

        logger.info("🎙️  录音开始... (说话后静音自动停止，最长 %ds)" % self.max_seconds)
        self._recording = True
        self._frames = []

        silence_frames = 0
        silence_limit = int(self.sample_rate / self.chunk_size * self.silence_threshold / 1000)
        max_frames = int(self.sample_rate / self.chunk_size * self.max_seconds)

        while self._recording and len(self._frames) < max_frames:
            data = stream.read(self.chunk_size, exception_on_overflow=False)
            self._frames.append(data)

            # 能量计算（静音检测）
            energy = _calc_energy(data)
            if energy < self.energy_threshold:
                silence_frames += 1
                if silence_frames >= silence_limit and len(self._frames) > silence_limit * 2:
                    logger.info("检测到静音，录音结束")
                    break
            else:
                silence_frames = 0

        stream.stop_stream()
        stream.close()
        pa.terminate()

        audio_bytes = b"".join(self._frames)
        logger.info(f"录音完成，时长 {len(audio_bytes) / (self.sample_rate * 2):.1f}s")

        if callback:
            callback(audio_bytes)

        return audio_bytes

    def stop(self):
        self._recording = False

    def record_to_file(self, file_path: str) -> str:
        """录音并保存到 WAV 文件"""
        audio_data = self.record()
        _write_wav(file_path, audio_data, self.sample_rate, self.channels)
        return file_path


# ─────────────────────────────────────────────
# ASR 工厂 & 门面类
# ─────────────────────────────────────────────
class ASRManager:
    """
    ASR 管理器（Step 2+3 的统一入口）
    流程：录音 → ASR识别 → 返回文字
    """

    def __init__(self, config):
        self.config = config
        self.recorder = AudioRecorder(
            sample_rate=config.asr.sample_rate,
            channels=config.asr.channels,
            chunk_size=config.asr.chunk_size,
            silence_threshold=config.asr.silence_threshold,
            max_seconds=config.asr.max_record_seconds,
            energy_threshold=config.asr.energy_threshold,
        )
        self.asr = self._build_asr(config.asr)

    def _build_asr(self, cfg) -> ASRBase:
        provider = cfg.provider.lower()
        logger.info(f"ASR 引擎: {provider}")
        if provider == "google":
            return GoogleASR(language=cfg.language)
        elif provider == "whisper":
            return WhisperASR(model_name=cfg.whisper_model)
        elif provider == "baidu":
            return BaiduASR(cfg.baidu_app_id, cfg.baidu_api_key, cfg.baidu_secret_key)
        else:
            return MockASR()

    def listen_and_transcribe(self) -> str:
        """完整流程：唤醒 → 录音 → 识别"""
        logger.info("=" * 50)
        logger.info("Step 2: 手机端唤醒与录音")
        audio_data = self.recorder.record()

        logger.info("Step 3: ASR 语音转文字")
        text = self.asr.recognize(audio_data, self.config.asr.sample_rate)
        logger.info(f"识别文字: 「{text}」")
        return text

    def transcribe_file(self, file_path: str) -> str:
        """直接识别音频文件"""
        return self.asr.recognize_file(file_path)

    def transcribe_bytes(self, audio_bytes: bytes) -> str:
        """识别音频字节流"""
        return self.asr.recognize(audio_bytes, self.config.asr.sample_rate)


# ─────────────────────────────────────────────
# 工具函数
# ─────────────────────────────────────────────
def _calc_energy(data: bytes) -> float:
    """计算音频能量（RMS）"""
    if len(data) < 2:
        return 0.0
    count = len(data) // 2
    shorts = struct.unpack(f"{count}h", data[:count * 2])
    rms = (sum(s * s for s in shorts) / count) ** 0.5
    return rms


def _write_wav(file_path: str, pcm_data: bytes, sample_rate: int, channels: int = 1):
    """将 PCM 数据写入 WAV 文件"""
    os.makedirs(os.path.dirname(file_path) if os.path.dirname(file_path) else ".", exist_ok=True)
    with wave.open(file_path, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(2)  # 16-bit
        wf.setframerate(sample_rate)
        wf.writeframes(pcm_data)
