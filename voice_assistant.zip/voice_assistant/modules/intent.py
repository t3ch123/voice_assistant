"""
Step 6: 大模型意图识别
解析用户输入，识别意图类型和实体
"""
import json
import re
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List
from enum import Enum

from modules.logger import setup_logger

logger = setup_logger("intent")


class TaskType(str, Enum):
    SIMPLE_QA = "simple_qa"        # 普通问答：直接生成回复
    COMPLEX_TASK = "complex_task"  # 复杂任务：拆解为多个步骤
    TOOL_CALL = "tool_call"        # 工具调用：调用 API/本地能力/数据接口
    MULTI_TURN = "multi_turn"      # 多轮对话：结合上下文继续处理


@dataclass
class IntentResult:
    """意图识别结果"""
    intent: str                            # 具体意图标签
    task_type: TaskType                    # 任务分类
    entities: Dict[str, Any] = field(default_factory=dict)  # 提取的实体
    confidence: float = 0.0               # 置信度
    description: str = ""                 # 意图描述
    raw_text: str = ""                    # 原始输入
    requires_context: bool = False        # 是否需要上下文

    def is_high_confidence(self, threshold: float = 0.7) -> bool:
        return self.confidence >= threshold

    def __str__(self):
        return (
            f"意图: {self.intent} | 类型: {self.task_type.value} | "
            f"置信度: {self.confidence:.0%} | 实体: {self.entities}"
        )


INTENT_PROMPT = """你是一个意图识别专家。请分析用户输入，识别意图并提取关键实体。

用户输入: "{user_input}"
历史对话摘要: {context_summary}

请严格以 JSON 格式返回（不要包含任何其他内容）:
{{
  "intent": "意图标签（英文，如 query_weather / set_alarm / calculate / translate / search / send_email / set_reminder / general_qa）",
  "task_type": "任务类型（simple_qa / complex_task / tool_call / multi_turn 之一）",
  "entities": {{"实体名": "实体值"}},
  "confidence": 置信度(0-1的小数),
  "description": "简短意图描述（中文）",
  "requires_context": true或false
}}

任务类型判断规则:
- simple_qa: 知识问答、闲聊、简单问题
- complex_task: 需要多步骤、多工具配合完成的任务
- tool_call: 需要调用特定工具（天气、计算、翻译、搜索、日历等）
- multi_turn: 引用了之前对话内容（"刚才说的"、"上面那个"等）"""


class IntentRecognizer:
    """
    意图识别器（Step 6）
    使用 LLM 进行语义理解和意图分类
    """

    def __init__(self, llm_manager):
        self.llm = llm_manager
        logger.info("意图识别器初始化完成")

    def recognize(self, user_input: str, context_summary: str = "无") -> IntentResult:
        """
        识别用户意图
        Returns: IntentResult
        """
        logger.info(f"Step 6: 大模型意图识别 → 输入: 「{user_input}」")

        if not user_input.strip():
            return IntentResult(
                intent="empty_input",
                task_type=TaskType.SIMPLE_QA,
                confidence=1.0,
                description="输入为空",
                raw_text=user_input,
            )

        prompt = INTENT_PROMPT.format(
            user_input=user_input,
            context_summary=context_summary,
        )

        messages = [{"role": "user", "content": prompt}]

        try:
            raw_resp = self.llm.chat(messages)
            result = self._parse_response(raw_resp, user_input)
            logger.info(f"意图识别结果: {result}")
            return result
        except Exception as e:
            logger.error(f"意图识别失败: {e}")
            return self._fallback_intent(user_input)

    def _parse_response(self, raw: str, user_input: str) -> IntentResult:
        """解析 LLM 返回的 JSON"""
        # 提取 JSON 块
        json_str = raw.strip()
        match = re.search(r"\{.*\}", json_str, re.DOTALL)
        if match:
            json_str = match.group()

        try:
            data = json.loads(json_str)
        except json.JSONDecodeError:
            logger.warning(f"JSON 解析失败，原始: {raw[:200]}")
            return self._fallback_intent(user_input)

        task_type_str = data.get("task_type", "simple_qa")
        try:
            task_type = TaskType(task_type_str)
        except ValueError:
            task_type = TaskType.SIMPLE_QA

        return IntentResult(
            intent=data.get("intent", "general_qa"),
            task_type=task_type,
            entities=data.get("entities", {}),
            confidence=float(data.get("confidence", 0.5)),
            description=data.get("description", ""),
            raw_text=user_input,
            requires_context=data.get("requires_context", False),
        )

    def _fallback_intent(self, user_input: str) -> IntentResult:
        """降级处理：基于规则的简单意图识别"""
        rules = {
            "tool_call": {
                "天气": ("query_weather", {"location": "当前位置"}),
                "闹钟": ("set_alarm", {}),
                "计算": ("calculate", {}),
                "翻译": ("translate", {}),
                "搜索": ("web_search", {"query": user_input}),
                "提醒": ("set_reminder", {}),
                "导航": ("navigation", {}),
                "电话": ("make_call", {}),
            },
            "complex_task": {
                "邮件": ("send_email", {}),
                "报告": ("generate_report", {}),
                "计划": ("create_plan", {}),
                "分析": ("analyze", {}),
            },
        }

        for task_type_str, patterns in rules.items():
            for keyword, (intent, entities) in patterns.items():
                if keyword in user_input:
                    return IntentResult(
                        intent=intent,
                        task_type=TaskType(task_type_str),
                        entities=entities,
                        confidence=0.7,
                        description=f"规则匹配: {keyword}",
                        raw_text=user_input,
                    )

        return IntentResult(
            intent="general_qa",
            task_type=TaskType.SIMPLE_QA,
            entities={},
            confidence=0.5,
            description="未识别到特定意图，按普通问答处理",
            raw_text=user_input,
        )
