"""
Step 7: 任务判断与处理
四种任务类型:
1. 普通问答 (simple_qa)   - 直接生成回复
2. 复杂任务 (complex_task) - 拆解为多个步骤
3. 工具调用 (tool_call)   - 调用 API/本地能力/数据接口
4. 多轮对话 (multi_turn)  - 结合上下文继续处理
"""
import json
import re
import time
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple

from modules.logger import setup_logger
from modules.intent import IntentResult, TaskType
from modules.tools import ToolRegistry, ToolResult
from modules.context import SessionState, MessageRole, ToolCall

logger = setup_logger("task_processor")


@dataclass
class TaskStep:
    """任务步骤（用于复杂任务拆解）"""
    step_id: int
    description: str
    tool_name: Optional[str] = None
    tool_params: Dict[str, Any] = field(default_factory=dict)
    result: Optional[str] = None
    success: bool = False


@dataclass
class TaskExecutionResult:
    """任务执行结果"""
    task_type: str
    intent: str
    steps: List[TaskStep] = field(default_factory=list)
    tool_results: List[Dict] = field(default_factory=list)
    final_answer: str = ""
    success: bool = True
    error: Optional[str] = None
    duration_ms: float = 0.0


# ─────────────────────────────────────────────
# 意图 → 工具映射
# ─────────────────────────────────────────────
INTENT_TOOL_MAP = {
    "query_weather": ("weather", lambda e: {"location": e.get("location", "北京"), "date": e.get("date", "今天")}),
    "set_alarm": ("alarm", lambda e: {"action": "set", "time": e.get("time", "明天早上8点"), "label": e.get("label", "闹钟")}),
    "list_alarms": ("alarm", lambda e: {"action": "list"}),
    "calculate": ("calculator", lambda e: {"expression": e.get("expression", "1+1")}),
    "translate": ("translate", lambda e: {"text": e.get("text", ""), "target_lang": e.get("target_lang", "英文")}),
    "set_reminder": ("reminder", lambda e: {"content": e.get("content", ""), "time": e.get("time", "今天"), "repeat": e.get("repeat", "none")}),
    "query_time": ("datetime", lambda e: {"query": "now"}),
}


class TaskProcessor:
    """
    任务处理器（Step 7 核心）
    根据意图类型路由到不同处理逻辑
    """

    def __init__(self, llm_manager, tool_registry: ToolRegistry, agent_config):
        self.llm = llm_manager
        self.tools = tool_registry
        self.config = agent_config
        logger.info("任务处理器初始化完成")

    def process(
        self,
        user_input: str,
        intent_result: IntentResult,
        session: SessionState,
    ) -> TaskExecutionResult:
        """
        Step 7 入口：任务判断与处理
        根据 task_type 路由
        """
        logger.info(f"Step 7: 任务处理 → 类型={intent_result.task_type.value} | 意图={intent_result.intent}")
        start = time.time()

        router = {
            TaskType.SIMPLE_QA: self._handle_simple_qa,
            TaskType.TOOL_CALL: self._handle_tool_call,
            TaskType.COMPLEX_TASK: self._handle_complex_task,
            TaskType.MULTI_TURN: self._handle_multi_turn,
        }

        handler = router.get(intent_result.task_type, self._handle_simple_qa)
        result = handler(user_input, intent_result, session)
        result.duration_ms = (time.time() - start) * 1000
        logger.info(f"任务处理完成 ({result.duration_ms:.0f}ms): {result.final_answer[:100]}")
        return result

    # ─────────────────────────────────────────
    # 1. 普通问答
    # ─────────────────────────────────────────
    def _handle_simple_qa(
        self, user_input: str, intent: IntentResult, session: SessionState
    ) -> TaskExecutionResult:
        """普通问答：直接让 LLM 生成回复"""
        logger.info("  → 普通问答模式：直接生成回复")
        messages = session.get_messages_for_llm(
            system_prompt=self.config.system_prompt,
            max_turns=self.config.max_context_turns,
        )
        messages.append({"role": "user", "content": user_input})

        try:
            answer = self.llm.chat(messages)
            return TaskExecutionResult(
                task_type=TaskType.SIMPLE_QA.value,
                intent=intent.intent,
                final_answer=answer,
                success=True,
            )
        except Exception as e:
            return TaskExecutionResult(
                task_type=TaskType.SIMPLE_QA.value,
                intent=intent.intent,
                final_answer="抱歉，我暂时无法回答这个问题，请稍后再试。",
                success=False,
                error=str(e),
            )

    # ─────────────────────────────────────────
    # 2. 工具调用
    # ─────────────────────────────────────────
    def _handle_tool_call(
        self, user_input: str, intent: IntentResult, session: SessionState
    ) -> TaskExecutionResult:
        """工具调用：根据意图选择并执行工具"""
        logger.info(f"  → 工具调用模式: 意图={intent.intent}")

        result = TaskExecutionResult(
            task_type=TaskType.TOOL_CALL.value,
            intent=intent.intent,
        )

        # 1. 确定工具和参数
        tool_name, params = self._resolve_tool(intent, user_input)

        if not tool_name:
            logger.warning(f"未找到匹配工具，降级为普通问答: {intent.intent}")
            return self._handle_simple_qa(user_input, intent, session)

        # 2. 执行工具
        logger.info(f"  调用工具: {tool_name}({params})")
        tool_result = self.tools.execute(tool_name, **params)

        # 3. 记录工具调用
        tc = ToolCall(
            tool_name=tool_name,
            tool_input=params,
            tool_result=tool_result.to_dict(),
            success=tool_result.success,
        )
        session.add_tool_call(tc)
        result.tool_results.append(tool_result.to_dict())

        # 4. 生成自然语言回复
        answer = self._generate_tool_answer(user_input, tool_result, session)
        result.final_answer = answer
        result.success = tool_result.success

        return result

    def _resolve_tool(self, intent: IntentResult, user_input: str) -> Tuple[Optional[str], Dict]:
        """解析意图 → 工具名和参数"""
        # 先查预定义映射
        if intent.intent in INTENT_TOOL_MAP:
            tool_name, param_fn = INTENT_TOOL_MAP[intent.intent]
            params = param_fn(intent.entities)
            return tool_name, params

        # 尝试从用户输入中提取计算表达式
        if intent.intent == "calculate" or "计算" in user_input or any(op in user_input for op in ["乘以", "×", "÷", "加", "减"]):
            expr_match = re.search(r"[\d\s+\-*/()×÷乘以除以加减]+", user_input)
            if expr_match:
                return "calculator", {"expression": expr_match.group().strip()}

        return None, {}

    def _generate_tool_answer(self, user_input: str, tool_result: ToolResult, session: SessionState) -> str:
        """让 LLM 根据工具结果生成自然语言回复"""
        messages = session.get_messages_for_llm(
            system_prompt=self.config.system_prompt,
            max_turns=5,
        )
        tool_data_str = json.dumps(tool_result.to_dict(), ensure_ascii=False)
        messages.append({
            "role": "user",
            "content": (
                f"用户问题: {user_input}\n"
                f"工具执行结果: {tool_data_str}\n\n"
                f"请根据工具结果，用自然、友好的语言回答用户的问题。不要重复工具数据的原始格式，要组织成自然的句子。"
            )
        })
        try:
            return self.llm.chat(messages)
        except Exception:
            return tool_result.message or "操作已完成。"

    # ─────────────────────────────────────────
    # 3. 复杂任务（多步骤拆解）
    # ─────────────────────────────────────────
    def _handle_complex_task(
        self, user_input: str, intent: IntentResult, session: SessionState
    ) -> TaskExecutionResult:
        """复杂任务：LLM 拆解步骤 → 逐步执行"""
        logger.info(f"  → 复杂任务模式: 拆解多步骤")

        result = TaskExecutionResult(
            task_type=TaskType.COMPLEX_TASK.value,
            intent=intent.intent,
        )

        # Step A: 让 LLM 拆解任务
        steps = self._decompose_task(user_input, intent, session)
        logger.info(f"  任务已拆解为 {len(steps)} 个步骤")

        # Step B: 逐步执行
        step_results = []
        for i, step in enumerate(steps):
            logger.info(f"  执行步骤 {i+1}/{len(steps)}: {step.description}")
            if step.tool_name and self.tools.get(step.tool_name):
                tool_result = self.tools.execute(step.tool_name, **step.tool_params)
                step.result = tool_result.message
                step.success = tool_result.success
                result.tool_results.append(tool_result.to_dict())
                tc = ToolCall(
                    tool_name=step.tool_name,
                    tool_input=step.tool_params,
                    tool_result=tool_result.to_dict(),
                    success=tool_result.success,
                )
                session.add_tool_call(tc)
            else:
                step.result = f"步骤 {i+1} 已完成: {step.description}"
                step.success = True

            result.steps.append(step)
            step_results.append(f"步骤{i+1}({step.description}): {step.result}")

        # Step C: 汇总结果（Step 8）
        summary = self._summarize_complex_result(user_input, step_results, session)
        result.final_answer = summary
        result.success = all(s.success for s in result.steps)
        return result

    def _decompose_task(
        self, user_input: str, intent: IntentResult, session: SessionState
    ) -> List[TaskStep]:
        """使用 LLM 将复杂任务拆解为步骤"""
        tools_desc = self.tools.get_tools_description()
        prompt = (
            f"用户请求: {user_input}\n"
            f"{tools_desc}\n\n"
            "请将此任务拆解为最多5个可执行步骤，用JSON数组返回:\n"
            '[{"step":1,"description":"步骤描述","tool_name":"工具名或null","tool_params":{}}]'
        )
        try:
            resp = self.llm.chat([{"role": "user", "content": prompt}])
            match = re.search(r"\[.*\]", resp, re.DOTALL)
            if match:
                steps_data = json.loads(match.group())
                return [
                    TaskStep(
                        step_id=s.get("step", i + 1),
                        description=s.get("description", ""),
                        tool_name=s.get("tool_name"),
                        tool_params=s.get("tool_params", {}),
                    )
                    for i, s in enumerate(steps_data[:self.config.max_tool_calls])
                ]
        except Exception as e:
            logger.warning(f"任务拆解失败: {e}，使用默认步骤")

        # 降级：生成通用步骤
        return [
            TaskStep(1, f"分析用户需求: {user_input}"),
            TaskStep(2, "收集必要信息"),
            TaskStep(3, "执行核心操作"),
            TaskStep(4, "整理并返回结果"),
        ]

    def _summarize_complex_result(
        self, user_input: str, step_results: List[str], session: SessionState
    ) -> str:
        """汇总多步骤结果（Step 8: Agent 汇总执行结果）"""
        logger.info("  Step 8: Agent 汇总执行结果")
        steps_summary = "\n".join(step_results)
        messages = [
            {
                "role": "user",
                "content": (
                    f"用户原始请求: {user_input}\n"
                    f"各步骤执行结果:\n{steps_summary}\n\n"
                    "请综合以上信息，用简洁自然的语言给用户一个完整的回复。"
                )
            }
        ]
        try:
            return self.llm.chat(messages)
        except Exception:
            return f"任务已完成！执行了{len(step_results)}个步骤：\n" + "\n".join(step_results)

    # ─────────────────────────────────────────
    # 4. 多轮对话
    # ─────────────────────────────────────────
    def _handle_multi_turn(
        self, user_input: str, intent: IntentResult, session: SessionState
    ) -> TaskExecutionResult:
        """多轮对话：结合上下文继续处理"""
        logger.info(f"  → 多轮对话模式 (已有 {len(session.messages)} 条历史)")

        messages = session.get_messages_for_llm(
            system_prompt=self.config.system_prompt + "\n注意：这是多轮对话，请结合上下文理解用户意图。",
            max_turns=self.config.max_context_turns,
        )
        messages.append({"role": "user", "content": user_input})

        try:
            answer = self.llm.chat(messages)
            return TaskExecutionResult(
                task_type=TaskType.MULTI_TURN.value,
                intent=intent.intent,
                final_answer=answer,
                success=True,
            )
        except Exception as e:
            return TaskExecutionResult(
                task_type=TaskType.MULTI_TURN.value,
                intent=intent.intent,
                final_answer="抱歉，我在理解上下文时遇到了问题，请重新描述您的需求。",
                success=False,
                error=str(e),
            )
