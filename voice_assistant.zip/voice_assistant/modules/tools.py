"""
Step 7-工具调用: 调用 API / 本地能力 / 数据接口
内置工具: 天气查询、计算器、翻译、搜索、闹钟、提醒等
"""
import json
import math
import re
import time
import datetime
import urllib.parse
import urllib.request
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Callable

from modules.logger import setup_logger

logger = setup_logger("tools")


# ─────────────────────────────────────────────
# 工具基类
# ─────────────────────────────────────────────
@dataclass
class ToolResult:
    success: bool
    data: Any
    message: str = ""
    tool_name: str = ""
    duration_ms: float = 0.0

    def to_dict(self) -> dict:
        return {
            "success": self.success,
            "data": self.data,
            "message": self.message,
            "tool_name": self.tool_name,
            "duration_ms": round(self.duration_ms, 2),
        }

    def __str__(self):
        status = "✅" if self.success else "❌"
        return f"{status} [{self.tool_name}] {self.message}: {self.data}"


class BaseTool(ABC):
    name: str = "base_tool"
    description: str = "基础工具"
    parameters: Dict[str, str] = {}

    @abstractmethod
    def execute(self, **kwargs) -> ToolResult: ...

    def safe_execute(self, **kwargs) -> ToolResult:
        start = time.time()
        try:
            result = self.execute(**kwargs)
            result.tool_name = self.name
            result.duration_ms = (time.time() - start) * 1000
            logger.info(f"工具[{self.name}] 执行成功: {result.message} ({result.duration_ms:.0f}ms)")
            return result
        except Exception as e:
            duration = (time.time() - start) * 1000
            logger.error(f"工具[{self.name}] 执行失败: {e}")
            return ToolResult(
                success=False,
                data=None,
                message=str(e),
                tool_name=self.name,
                duration_ms=duration,
            )


# ─────────────────────────────────────────────
# 天气查询工具
# ─────────────────────────────────────────────
class WeatherTool(BaseTool):
    name = "weather"
    description = "查询指定城市的实时天气信息"
    parameters = {
        "location": "城市名称（如：北京、上海、广州）",
        "date": "日期（今天/明天/后天，默认今天）",
    }

    # 使用 wttr.in 的免费 API
    WTTR_URL = "https://wttr.in/{location}?format=j1&lang=zh"

    # 模拟数据（当 API 不可用时）
    MOCK_DATA = {
        "default": {
            "temp_c": 22, "feels_like_c": 20, "humidity": 65,
            "wind_kph": 12, "condition": "晴天", "uv_index": 5,
            "air_quality": "良好", "forecast_max": 26, "forecast_min": 15,
        }
    }

    def execute(self, location: str = "北京", date: str = "今天", **kwargs) -> ToolResult:
        logger.info(f"查询天气: {location} ({date})")
        try:
            url = self.WTTR_URL.format(location=urllib.parse.quote(location))
            req = urllib.request.Request(url, headers={"User-Agent": "VoiceAssistant/1.0"})
            with urllib.request.urlopen(req, timeout=5) as resp:
                raw = json.loads(resp.read().decode("utf-8"))
            current = raw["current_condition"][0]
            data = {
                "location": location,
                "date": date,
                "temp_c": int(current["temp_C"]),
                "feels_like_c": int(current["FeelsLikeC"]),
                "humidity": int(current["humidity"]),
                "wind_kph": int(current["windspeedKmph"]),
                "condition": current["lang_zh"][0]["value"] if current.get("lang_zh") else current["weatherDesc"][0]["value"],
                "uv_index": int(current.get("uvIndex", 0)),
                "forecast_max": int(raw["weather"][0]["maxtempC"]),
                "forecast_min": int(raw["weather"][0]["mintempC"]),
            }
            msg = f"{location}{date}：{data['condition']}，{data['temp_c']}°C，湿度{data['humidity']}%"
            return ToolResult(success=True, data=data, message=msg)
        except Exception:
            # 降级到模拟数据
            mock = self.MOCK_DATA["default"].copy()
            mock["location"] = location
            mock["date"] = date
            msg = f"{location}{date}（模拟）：{mock['condition']}，{mock['temp_c']}°C，湿度{mock['humidity']}%"
            return ToolResult(success=True, data=mock, message=msg)


# ─────────────────────────────────────────────
# 计算器工具
# ─────────────────────────────────────────────
class CalculatorTool(BaseTool):
    name = "calculator"
    description = "执行数学计算，支持四则运算、科学计算"
    parameters = {"expression": "数学表达式（如：1234 * 5678 或 sqrt(144)）"}

    # 安全的数学函数白名单
    SAFE_GLOBALS = {
        "__builtins__": {},
        "abs": abs, "round": round, "min": min, "max": max,
        "sqrt": math.sqrt, "pow": math.pow, "log": math.log,
        "log10": math.log10, "sin": math.sin, "cos": math.cos,
        "tan": math.tan, "pi": math.pi, "e": math.e,
        "floor": math.floor, "ceil": math.ceil,
    }

    # 中文数学表达式替换
    REPLACEMENTS = [
        ("乘以", "*"), ("×", "*"), ("除以", "/"), ("÷", "/"),
        ("加", "+"), ("减", "-"), ("平方根", "sqrt"), ("的平方", "**2"),
        ("的立方", "**3"), ("百分之", "0."), ("万", "*10000"),
    ]

    def execute(self, expression: str = "1+1", **kwargs) -> ToolResult:
        expr = expression.strip()
        for cn, en in self.REPLACEMENTS:
            expr = expr.replace(cn, en)
        try:
            result = eval(expr, self.SAFE_GLOBALS, {})
            if isinstance(result, float) and result == int(result):
                result = int(result)
            formatted = f"{expression} = {result}"
            return ToolResult(success=True, data={"expression": expression, "result": result}, message=formatted)
        except Exception as e:
            return ToolResult(success=False, data=None, message=f"计算失败: {e}")


# ─────────────────────────────────────────────
# 翻译工具
# ─────────────────────────────────────────────
class TranslateTool(BaseTool):
    name = "translate"
    description = "翻译文本，支持中英互译"
    parameters = {
        "text": "要翻译的文本",
        "target_lang": "目标语言（英文/中文/日文/韩文）",
    }

    # 简单的中英字典（演示用）
    SIMPLE_DICT = {
        "人工智能": "Artificial Intelligence",
        "机器学习": "Machine Learning",
        "深度学习": "Deep Learning",
        "自然语言处理": "Natural Language Processing",
        "语音助手": "Voice Assistant",
        "智能手机": "Smartphone",
        "云计算": "Cloud Computing",
        "大数据": "Big Data",
    }

    def execute(self, text: str = "", target_lang: str = "英文", **kwargs) -> ToolResult:
        if not text:
            return ToolResult(success=False, data=None, message="翻译文本不能为空")

        # 检查简单字典
        if text in self.SIMPLE_DICT and "英" in target_lang:
            translated = self.SIMPLE_DICT[text]
            return ToolResult(
                success=True,
                data={"original": text, "translated": translated, "target_lang": target_lang},
                message=f"「{text}」→ {translated}"
            )

        # 尝试使用 MyMemory 免费翻译 API
        try:
            lang_map = {"英文": "en", "中文": "zh", "日文": "ja", "韩文": "ko", "法文": "fr"}
            target_code = lang_map.get(target_lang, "en")
            source_code = "zh" if any('\u4e00' <= c <= '\u9fff' for c in text) else "en"
            url = f"https://api.mymemory.translated.net/get?q={urllib.parse.quote(text)}&langpair={source_code}|{target_code}"
            req = urllib.request.Request(url, headers={"User-Agent": "VoiceAssistant/1.0"})
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = json.loads(resp.read())
            translated = data["responseData"]["translatedText"]
            return ToolResult(
                success=True,
                data={"original": text, "translated": translated, "target_lang": target_lang},
                message=f"「{text}」→ {translated}"
            )
        except Exception:
            # 模拟翻译
            mock_result = f"[Translation of: {text}]"
            return ToolResult(
                success=True,
                data={"original": text, "translated": mock_result, "target_lang": target_lang},
                message=f"「{text}」→ {mock_result}（模拟翻译）"
            )


# ─────────────────────────────────────────────
# 闹钟工具
# ─────────────────────────────────────────────
class AlarmTool(BaseTool):
    name = "alarm"
    description = "设置/查询/删除闹钟"
    parameters = {
        "action": "操作类型（set/list/delete）",
        "time": "闹钟时间（如：明天早上8点）",
        "label": "闹钟标签（可选）",
    }
    _alarms: List[Dict] = []

    def execute(self, action: str = "set", time: str = "", label: str = "闹钟", **kwargs) -> ToolResult:
        if action == "set":
            alarm = {
                "id": len(self._alarms) + 1,
                "time": time,
                "label": label,
                "created_at": datetime.datetime.now().isoformat(),
                "active": True,
            }
            self._alarms.append(alarm)
            return ToolResult(success=True, data=alarm, message=f"闹钟已设置: {time} ({label})")

        elif action == "list":
            active = [a for a in self._alarms if a["active"]]
            return ToolResult(success=True, data=active, message=f"当前有 {len(active)} 个活跃闹钟")

        elif action == "delete":
            deleted = [a for a in self._alarms if a.get("label") == label or str(a.get("id")) == str(time)]
            for a in deleted:
                a["active"] = False
            return ToolResult(success=True, data=deleted, message=f"已删除 {len(deleted)} 个闹钟")

        return ToolResult(success=False, data=None, message=f"未知操作: {action}")


# ─────────────────────────────────────────────
# 提醒工具
# ─────────────────────────────────────────────
class ReminderTool(BaseTool):
    name = "reminder"
    description = "设置事项提醒"
    parameters = {
        "content": "提醒内容",
        "time": "提醒时间",
        "repeat": "重复（daily/weekly/none）",
    }
    _reminders: List[Dict] = []

    def execute(self, content: str = "", time: str = "今天", repeat: str = "none", **kwargs) -> ToolResult:
        reminder = {
            "id": len(self._reminders) + 1,
            "content": content,
            "time": time,
            "repeat": repeat,
            "created_at": datetime.datetime.now().isoformat(),
        }
        self._reminders.append(reminder)
        return ToolResult(success=True, data=reminder, message=f"提醒已设置: {time} - {content}")


# ─────────────────────────────────────────────
# 日期时间工具
# ─────────────────────────────────────────────
class DateTimeTool(BaseTool):
    name = "datetime"
    description = "获取当前日期时间、计算日期差等"
    parameters = {"query": "查询内容（now/date/time/weekday/days_until）"}

    def execute(self, query: str = "now", **kwargs) -> ToolResult:
        now = datetime.datetime.now()
        weekdays = ["星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"]
        data = {
            "datetime": now.strftime("%Y-%m-%d %H:%M:%S"),
            "date": now.strftime("%Y年%m月%d日"),
            "time": now.strftime("%H:%M:%S"),
            "weekday": weekdays[now.weekday()],
            "timestamp": int(now.timestamp()),
        }
        msg = f"当前时间: {data['date']} {data['weekday']} {data['time']}"
        return ToolResult(success=True, data=data, message=msg)


# ─────────────────────────────────────────────
# 工具注册表
# ─────────────────────────────────────────────
class ToolRegistry:
    """工具注册与管理中心"""

    def __init__(self):
        self._tools: Dict[str, BaseTool] = {}
        self._register_builtin_tools()

    def _register_builtin_tools(self):
        """注册内置工具"""
        builtin = [
            WeatherTool(),
            CalculatorTool(),
            TranslateTool(),
            AlarmTool(),
            ReminderTool(),
            DateTimeTool(),
        ]
        for tool in builtin:
            self.register(tool)
        logger.info(f"已注册 {len(self._tools)} 个内置工具: {list(self._tools.keys())}")

    def register(self, tool: BaseTool):
        self._tools[tool.name] = tool
        logger.debug(f"注册工具: {tool.name} - {tool.description}")

    def get(self, name: str) -> Optional[BaseTool]:
        return self._tools.get(name)

    def list_tools(self) -> List[Dict]:
        return [
            {"name": t.name, "description": t.description, "parameters": t.parameters}
            for t in self._tools.values()
        ]

    def execute(self, tool_name: str, **kwargs) -> ToolResult:
        """执行指定工具"""
        tool = self.get(tool_name)
        if not tool:
            return ToolResult(
                success=False,
                data=None,
                message=f"工具 '{tool_name}' 不存在",
                tool_name=tool_name,
            )
        return tool.safe_execute(**kwargs)

    def get_tools_description(self) -> str:
        """生成工具列表文本（用于 LLM Prompt）"""
        lines = ["可用工具列表:"]
        for tool in self._tools.values():
            params = ", ".join(f"{k}: {v}" for k, v in tool.parameters.items())
            lines.append(f"  - {tool.name}: {tool.description} | 参数: {params}")
        return "\n".join(lines)


