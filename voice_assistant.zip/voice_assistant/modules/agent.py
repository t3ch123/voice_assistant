"""
Step 5 & 8: Agent 接收用户指令 / Agent 汇总执行结果
核心 Agent 类，协调所有模块完成完整工作流
"""
import time
import uuid
from dataclasses import dataclass, field
from typing import Optional, Dict, Any

from modules.logger import setup_logger
from modules.context import ContextManager, SessionState, MessageRole
from modules.intent import IntentRecognizer, IntentResult, TaskType
from modules.task_processor import TaskProcessor, TaskExecutionResult
from modules.tools import ToolRegistry
from modules.llm_client import LLMManager

logger = setup_logger("agent")


@dataclass
class AgentResponse:
    """Agent 最终响应"""
    session_id: str
    user_input: str
    text_response: str             # Step 9: 大模型生成的自然语言回复
    intent: str = ""
    task_type: str = ""
    tool_results: list = field(default_factory=list)
    success: bool = True
    error: Optional[str] = None
    latency_ms: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __str__(self):
        status = "✅" if self.success else "❌"
        return (
            f"{status} [{self.task_type}] {self.text_response[:100]}"
            f" ({self.latency_ms:.0f}ms)"
        )


class Agent:
    """
    移动端 AI 语音助手 Agent
    完整工作流: Step 5 → Step 6 → Step 7 → Step 8 → Step 9
    """

    def __init__(self, config):
        self.config = config
        logger.info("=" * 60)
        logger.info(f"初始化 {config.app_name} v{config.version}")
        logger.info("=" * 60)

        # 初始化各模块
        self.llm = LLMManager(config)
        self.tools = ToolRegistry()
        self.context_manager = ContextManager(
            max_turns=config.agent.max_context_turns
        )
        self.intent_recognizer = IntentRecognizer(self.llm)
        self.task_processor = TaskProcessor(self.llm, self.tools, config.agent)

        logger.info("Agent 初始化完成，所有模块就绪 ✅")

    def process(
        self,
        user_input: str,
        session_id: Optional[str] = None,
        user_id: str = "default",
    ) -> AgentResponse:
        """
        完整 Agent 工作流入口
        Steps 5 → 6 → 7 → 8 → 9
        """
        start_time = time.time()
        session_id = session_id or str(uuid.uuid4())[:8]

        logger.info("\n" + "=" * 60)
        logger.info(f"🎯 用户输入: 「{user_input}」")
        logger.info(f"   Session: {session_id}")
        logger.info("=" * 60)

        # Step 5: Agent 接收用户指令
        logger.info("Step 5: Agent 接收用户指令")
        session = self.context_manager.get_or_create_session(session_id, user_id)

        # 记录用户消息
        session.add_message(MessageRole.USER, user_input)

        # 检查空输入
        if not user_input.strip():
            resp = AgentResponse(
                session_id=session_id,
                user_input=user_input,
                text_response="您好！请问有什么我可以帮助您的？",
                intent="empty_input",
                task_type="simple_qa",
                latency_ms=(time.time() - start_time) * 1000,
            )
            session.add_message(MessageRole.ASSISTANT, resp.text_response)
            return resp

        try:
            # Step 6: 大模型意图识别
            context_summary = self._get_context_summary(session)
            intent_result = self.intent_recognizer.recognize(user_input, context_summary)

            # 多轮对话检测：如果有历史消息且用户引用了上下文
            if len(session.messages) > 2 and intent_result.requires_context:
                intent_result.task_type = TaskType.MULTI_TURN

            # Step 7: 任务判断与处理
            task_result = self.task_processor.process(user_input, intent_result, session)

            # Step 8: Agent 汇总执行结果（已在 task_processor 内完成）
            logger.info("Step 8: Agent 汇总执行结果")

            # Step 9: 大模型生成自然语言回复
            logger.info("Step 9: 大模型生成自然语言回复")
            final_text = task_result.final_answer

            # 记录 Assistant 回复到上下文
            session.add_message(MessageRole.ASSISTANT, final_text)
            session.current_task_type = task_result.task_type

            latency = (time.time() - start_time) * 1000
            logger.info(f"✅ 总耗时: {latency:.0f}ms")

            return AgentResponse(
                session_id=session_id,
                user_input=user_input,
                text_response=final_text,
                intent=intent_result.intent,
                task_type=task_result.task_type,
                tool_results=task_result.tool_results,
                success=task_result.success,
                latency_ms=latency,
                metadata={
                    "confidence": intent_result.confidence,
                    "steps_count": len(task_result.steps),
                    "entities": intent_result.entities,
                },
            )

        except Exception as e:
            logger.exception(f"Agent 处理异常: {e}")
            error_msg = "抱歉，我在处理您的请求时遇到了问题，请稍后重试。"
            session.add_message(MessageRole.ASSISTANT, error_msg)
            return AgentResponse(
                session_id=session_id,
                user_input=user_input,
                text_response=error_msg,
                success=False,
                error=str(e),
                latency_ms=(time.time() - start_time) * 1000,
            )

    def _get_context_summary(self, session: SessionState) -> str:
        """生成上下文摘要"""
        if not session.messages:
            return "无历史对话"
        recent = session.messages[-6:]
        lines = []
        for msg in recent:
            role_name = "用户" if msg.role == MessageRole.USER else "助手"
            lines.append(f"{role_name}: {msg.content[:50]}")
        return " | ".join(lines)

    def get_session_info(self, session_id: str) -> Optional[dict]:
        session = self.context_manager.get_session(session_id)
        if not session:
            return None
        return session.get_summary()

    def clear_session(self, session_id: str):
        session = self.context_manager.get_session(session_id)
        if session:
            session.clear_history()

    def list_tools(self) -> list:
        return self.tools.list_tools()
