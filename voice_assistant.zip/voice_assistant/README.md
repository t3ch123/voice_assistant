# 移动端 AI 语音助手 Agent

> 从语音输入到任务处理，再到结果反馈的完整工作流

## 🏗️ 项目结构

```
voice_assistant/
├── main.py                    # 主入口（支持 demo/text/voice/server 模式）
├── config.py                  # 全局配置（LLM/ASR/TTS/Server）
├── requirements.txt           # 依赖包列表
├── modules/
│   ├── logger.py              # 日志工具
│   ├── asr.py                 # Step 2-3: 录音 + ASR 语音转文字
│   ├── llm_client.py          # Step 6/9: 大模型客户端（OpenAI/Anthropic/智谱/Mock）
│   ├── intent.py              # Step 6: 意图识别
│   ├── context.py             # 多轮对话上下文管理
│   ├── tools.py               # Step 7: 工具调用（天气/计算/翻译/闹钟等）
│   ├── task_processor.py      # Step 7: 四种任务处理器
│   ├── agent.py               # Step 5/8: Agent 核心协调器
│   └── tts.py                 # Step 11: TTS 语音合成播放
├── server/
│   └── app.py                 # Step 4/10: Flask REST API 后端
├── tests/
│   └── test_agent.py          # 单元测试 + 集成测试
├── logs/                      # 日志目录
└── audio_cache/               # 音频缓存目录
```

## 📋 完整工作流

```
Step 1  用户语音输入
    ↓
Step 2  手机端唤醒与录音（AudioRecorder）
    ↓
Step 3  ASR 语音转文字（Google/Whisper/百度/Mock）
    ↓
Step 4  文本发送至后端服务（Flask API / 本地）
    ↓
Step 5  Agent 接收用户指令（Agent.process）
    ↓
Step 6  大模型意图识别（IntentRecognizer）
    ↓
Step 7  任务判断与处理（TaskProcessor）
    ├── 普通问答    → LLM 直接生成回复
    ├── 复杂任务    → 任务拆解 → 逐步执行
    ├── 工具调用    → 天气/计算/翻译/闹钟/提醒
    └── 多轮对话    → 结合上下文继续处理
    ↓
Step 8  Agent 汇总执行结果
    ↓
Step 9  大模型生成自然语言回复
    ↓
Step 10 文字返回手机端（API Response）
    ↓
Step 11 TTS 语音播报 / 页面展示结果（gTTS/pyttsx3/Mock）
```

## ⚡ 快速开始

### 1. 安装依赖（最小安装）

```bash
pip install flask flask-cors
```

### 2. 运行演示（无需 API Key）

```bash
cd voice_assistant
python main.py demo
```

### 3. 文字交互模式

```bash
python main.py text
```

### 4. 启动 API 服务器

```bash
python main.py server --port 8000
```

### 5. 运行测试

```bash
python tests/test_agent.py
```

## 🔧 配置 API Key（可选，不配置则使用 Mock 模式）

### OpenAI
```bash
export OPENAI_API_KEY=sk-xxx
```

### Anthropic Claude
```bash
export ANTHROPIC_API_KEY=sk-ant-xxx
```

### 智谱 AI（国内推荐）
```bash
export ZHIPU_API_KEY=xxx.xxx
```

## 🌐 API 接口文档

启动服务器后，可调用以下接口：

### 健康检查
```
GET /health
```

### 文字对话（核心接口）
```
POST /api/chat
Content-Type: application/json

{
    "text": "今天北京天气怎么样",
    "session_id": "可选，用于多轮对话",
    "user_id": "可选"
}
```

**响应：**
```json
{
    "session_id": "abc12345",
    "text": "根据最新气象数据，北京今天天气晴朗...",
    "intent": "query_weather",
    "task_type": "tool_call",
    "tool_results": [...],
    "success": true,
    "latency_ms": 245.8
}
```

### 语音识别（ASR）
```
POST /api/voice/recognize
Content-Type: multipart/form-data

file: <音频文件>
```

### 语音全流程处理
```
POST /api/voice/process?return_audio=true
Content-Type: multipart/form-data

file: <音频文件>
session_id: 可选
```

### TTS 文字转语音
```
POST /api/tts
Content-Type: application/json

{"text": "你好，我是语音助手"}
```

### 直接调用工具
```
POST /api/tools/weather
Content-Type: application/json

{"location": "上海", "date": "明天"}
```

### 获取会话信息
```
GET /api/session/{session_id}
```

### 清空会话上下文
```
POST /api/session/{session_id}/clear
```

### 流式聊天（SSE）
```
POST /api/chat/stream
Content-Type: application/json

{"text": "讲一个故事", "session_id": "可选"}
```

## 🔧 内置工具

| 工具名 | 功能 | 参数 |
|--------|------|------|
| `weather` | 天气查询（wttr.in API）| location, date |
| `calculator` | 数学计算 | expression |
| `translate` | 中英互译（MyMemory API）| text, target_lang |
| `alarm` | 闹钟管理 | action, time, label |
| `reminder` | 事项提醒 | content, time, repeat |
| `datetime` | 日期时间查询 | query |

## 🤖 支持的 LLM

| Provider | 模型 | 配置 |
|----------|------|------|
| OpenAI | gpt-4o-mini（默认）| `OPENAI_API_KEY` |
| Anthropic | claude-3-haiku | `ANTHROPIC_API_KEY` |
| 智谱 AI | glm-4-flash | `ZHIPU_API_KEY` |
| Mock | 内置规则引擎 | 无需配置 |

## 🎤 支持的 ASR

| Provider | 特点 | 配置 |
|----------|------|------|
| Google STT | 免费，需网络 | 无需 API Key |
| OpenAI Whisper | 本地离线 | `pip install openai-whisper` |
| 百度 ASR | 国内推荐 | `BAIDU_APP_ID/API_KEY/SECRET_KEY` |
| Mock | 模拟输入，测试用 | 自动切换 |

## 🔊 支持的 TTS

| Provider | 特点 | 安装 |
|----------|------|------|
| gTTS | Google TTS，需网络 | `pip install gTTS` |
| pyttsx3 | 本地离线 | `pip install pyttsx3` |
| 百度 TTS | 中文效果好 | `pip install baidu-aip` |
| Mock | 文字打印，测试用 | 自动切换 |

## 🧩 核心能力

- **任务理解** - 基于 LLM 的语义意图识别
- **任务拆解** - 复杂任务自动分解为多步骤
- **上下文保持** - 多轮对话记忆管理
- **工具/API 调用** - 可扩展的工具注册系统

## 📝 示例交互

```
场景1 天气查询 [工具调用]
👤 您: 今天北京天气怎么样
🤖 助手: 根据最新气象数据，北京今天天气晴朗，气温22°C，湿度65%，非常适合外出活动！

场景2 数学计算 [工具调用]
👤 您: 计算1234乘以5678
🤖 助手: 计算结果：1234 × 5678 = 7,006,652

场景3 多轮对话
👤 您: 什么是量子计算
🤖 助手: 量子计算是利用量子力学原理进行信息处理的计算方式...
👤 您: 能举个生活中的例子吗  ← 自动关联上下文
🤖 助手: 当然！以量子计算破解密码为例...
```
