"""
单元测试 & 集成测试
"""
import sys
import os
import json
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestTools(unittest.TestCase):
    """工具模块测试"""

    def setUp(self):
        from modules.tools import ToolRegistry
        self.registry = ToolRegistry()

    def test_calculator_basic(self):
        result = self.registry.execute("calculator", expression="2 + 3")
        self.assertTrue(result.success)
        self.assertEqual(result.data["result"], 5)

    def test_calculator_multiply(self):
        result = self.registry.execute("calculator", expression="1234 * 5678")
        self.assertTrue(result.success)
        self.assertEqual(result.data["result"], 1234 * 5678)

    def test_weather_tool(self):
        result = self.registry.execute("weather", location="北京", date="今天")
        self.assertTrue(result.success)
        self.assertIn("location", result.data)
        self.assertIn("temp_c", result.data)

    def test_alarm_set(self):
        result = self.registry.execute("alarm", action="set", time="明天早上8点", label="测试闹钟")
        self.assertTrue(result.success)
        self.assertEqual(result.data["time"], "明天早上8点")

    def test_alarm_list(self):
        self.registry.execute("alarm", action="set", time="明天早上8点")
        result = self.registry.execute("alarm", action="list")
        self.assertTrue(result.success)
        self.assertIsInstance(result.data, list)

    def test_datetime_tool(self):
        result = self.registry.execute("datetime", query="now")
        self.assertTrue(result.success)
        self.assertIn("datetime", result.data)

    def test_reminder_tool(self):
        result = self.registry.execute("reminder", content="重要会议", time="明天下午3点")
        self.assertTrue(result.success)

    def test_translate_tool(self):
        result = self.registry.execute("translate", text="人工智能", target_lang="英文")
        self.assertTrue(result.success)
        self.assertIn("translated", result.data)

    def test_tool_not_found(self):
        result = self.registry.execute("nonexistent_tool")
        self.assertFalse(result.success)

    def test_list_tools(self):
        tools = self.registry.list_tools()
        self.assertGreater(len(tools), 0)
        for tool in tools:
            self.assertIn("name", tool)
            self.assertIn("description", tool)


class TestContext(unittest.TestCase):
    """上下文管理测试"""

    def setUp(self):
        from modules.context import ContextManager
        self.ctx = ContextManager(max_turns=10)

    def test_create_session(self):
        session = self.ctx.get_or_create_session()
        self.assertIsNotNone(session.session_id)

    def test_session_persistence(self):
        session = self.ctx.get_or_create_session("test-123")
        session_id = session.session_id
        session2 = self.ctx.get_or_create_session(session_id)
        self.assertEqual(session.session_id, session2.session_id)

    def test_add_messages(self):
        from modules.context import MessageRole
        session = self.ctx.get_or_create_session()
        session.add_message(MessageRole.USER, "你好")
        session.add_message(MessageRole.ASSISTANT, "您好！")
        self.assertEqual(len(session.messages), 2)

    def test_messages_for_llm(self):
        from modules.context import MessageRole
        session = self.ctx.get_or_create_session()
        session.add_message(MessageRole.USER, "测试消息")
        msgs = session.get_messages_for_llm(system_prompt="系统提示")
        self.assertGreater(len(msgs), 0)
        self.assertEqual(msgs[0]["role"], "system")

    def test_clear_history(self):
        from modules.context import MessageRole
        session = self.ctx.get_or_create_session()
        session.add_message(MessageRole.USER, "测试")
        session.clear_history()
        self.assertEqual(len(session.messages), 0)


class TestIntent(unittest.TestCase):
    """意图识别测试"""

    def setUp(self):
        from config import config
        from modules.llm_client import LLMManager
        from modules.intent import IntentRecognizer
        # 强制使用 Mock LLM
        config.llm.provider = "mock"
        llm = LLMManager(config)
        self.recognizer = IntentRecognizer(llm)

    def test_recognize_weather(self):
        from modules.intent import TaskType
        result = self.recognizer.recognize("今天天气怎么样")
        self.assertIsNotNone(result)
        self.assertIn(result.task_type, list(TaskType))

    def test_recognize_calculate(self):
        result = self.recognizer.recognize("计算1234乘以5678")
        self.assertIsNotNone(result.intent)

    def test_empty_input(self):
        result = self.recognizer.recognize("")
        self.assertEqual(result.intent, "empty_input")

    def test_confidence_range(self):
        result = self.recognizer.recognize("帮我查天气")
        self.assertGreaterEqual(result.confidence, 0.0)
        self.assertLessEqual(result.confidence, 1.0)


class TestAgent(unittest.TestCase):
    """Agent 集成测试"""

    def setUp(self):
        from config import config
        config.llm.provider = "mock"
        config.asr.provider = "mock"
        config.tts.provider = "mock"
        from modules.agent import Agent
        self.agent = Agent(config)

    def test_process_simple_qa(self):
        response = self.agent.process("你好，请自我介绍一下")
        self.assertIsNotNone(response)
        self.assertIsNotNone(response.text_response)
        self.assertTrue(len(response.text_response) > 0)
        self.assertIsNotNone(response.session_id)

    def test_process_weather_query(self):
        response = self.agent.process("今天北京天气怎么样")
        self.assertIsNotNone(response.text_response)

    def test_process_calculation(self):
        response = self.agent.process("计算1234乘以5678")
        self.assertIsNotNone(response.text_response)

    def test_multi_turn_context(self):
        # 第一轮
        r1 = self.agent.process("什么是机器学习", session_id="test-multi")
        self.assertIsNotNone(r1.session_id)
        # 第二轮（应该能获取上下文）
        r2 = self.agent.process("能举个例子吗", session_id=r1.session_id)
        self.assertIsNotNone(r2.text_response)

    def test_session_management(self):
        response = self.agent.process("测试会话", session_id="test-session-mgmt")
        info = self.agent.get_session_info(response.session_id)
        self.assertIsNotNone(info)
        self.assertIn("session_id", info)

    def test_list_tools(self):
        tools = self.agent.list_tools()
        self.assertIsInstance(tools, list)
        self.assertGreater(len(tools), 0)

    def test_latency_tracked(self):
        response = self.agent.process("测试延迟追踪")
        self.assertGreater(response.latency_ms, 0)


class TestLLMClient(unittest.TestCase):
    """LLM 客户端测试（Mock）"""

    def setUp(self):
        from modules.llm_client import MockLLMClient
        self.llm = MockLLMClient()

    def test_chat_returns_string(self):
        messages = [{"role": "user", "content": "你好"}]
        result = self.llm.chat(messages)
        self.assertIsInstance(result, str)
        self.assertTrue(len(result) > 0)

    def test_chat_stream(self):
        messages = [{"role": "user", "content": "你好"}]
        chunks = list(self.llm.chat_stream(messages))
        self.assertGreater(len(chunks), 0)
        full_text = "".join(chunks)
        self.assertTrue(len(full_text) > 0)

    def test_weather_intent_mock(self):
        messages = [{"role": "user", "content": "请以JSON格式识别意图: 今天天气怎么样"}]
        result = self.llm.chat(messages)
        self.assertIsInstance(result, str)


def run_all_tests():
    """运行所有测试"""
    print("\n" + "=" * 60)
    print("  🧪 运行单元测试")
    print("=" * 60)

    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    test_classes = [TestTools, TestContext, TestIntent, TestAgent, TestLLMClient]
    for cls in test_classes:
        tests = loader.loadTestsFromTestCase(cls)
        suite.addTests(tests)

    runner = unittest.TextTestRunner(verbosity=2, stream=sys.stdout)
    result = runner.run(suite)

    print(f"\n{'=' * 60}")
    if result.wasSuccessful():
        print(f"  ✅ 所有测试通过！({result.testsRun} 个测试)")
    else:
        print(f"  ❌ 测试失败: {len(result.failures)} 失败, {len(result.errors)} 错误")
    print("=" * 60)

    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
