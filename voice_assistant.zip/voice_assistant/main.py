"""
移动端 AI 语音助手 Agent - 主入口
完整工作流: 语音输入 → ASR → Agent → TTS → 语音播报
"""
import sys
import os
import argparse
import time

# 确保项目根目录在 Python 路径中
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import config
from modules.logger import setup_logger, logger
from modules.agent import Agent
from modules.asr import ASRManager
from modules.tts import TTSManager

# ─────────────────────────────────────────────────────────────────
# 完整语音助手工作流
# ─────────────────────────────────────────────────────────────────

class VoiceAssistant:
    """
    移动端 AI 语音助手 - 完整工作流
    
    流程: 
    Step 1  用户语音输入
    Step 2  手机端唤醒与录音
    Step 3  ASR 语音转文字
    Step 4  文本发送至后端服务
    Step 5  Agent 接收用户指令
    Step 6  大模型意图识别
    Step 7  任务判断与处理 (普通问答/复杂任务/工具调用/多轮对话)
    Step 8  Agent 汇总执行结果
    Step 9  大模型生成自然语言回复
    Step 10 文字返回手机端
    Step 11 TTS 语音播报 / 页面展示结果
    """

    def __init__(self):
        logger.info("=" * 60)
        logger.info(f"  {config.app_name} v{config.version}")
        logger.info("  从语音输入到任务处理，再到结果反馈的完整流程")
        logger.info("=" * 60)

        self.agent = Agent(config)
        self.asr = ASRManager(config)
        self.tts = TTSManager(config)
        self.session_id = None
        self._running = False

    def run_voice_mode(self):
        """语音交互模式（Step 1-11 完整流程）"""
        self._running = True
        print("\n🎙️  语音助手已启动！")
        print("   按 Enter 开始录音，说话后静音自动停止")
        print("   输入 'q' 退出\n")

        while self._running:
            try:
                cmd = input("⏎ 按 Enter 开始录音 (q=退出): ").strip()
                if cmd.lower() in ("q", "quit", "exit"):
                    break

                # Step 1: 用户语音输入
                print("\n🎙️  Step 1: 用户语音输入")

                # Step 2 & 3: 录音 + ASR
                user_text = self.asr.listen_and_transcribe()

                if not user_text:
                    print("⚠️  未识别到语音内容，请重试\n")
                    continue

                # Step 4-9: Agent 处理（包含文本发送、处理、生成回复）
                self._process_and_respond(user_text)

            except KeyboardInterrupt:
                print("\n\n👋 退出语音助手")
                break
            except Exception as e:
                logger.error(f"语音交互出错: {e}")
                print(f"❌ 发生错误: {e}\n")

    def run_text_mode(self):
        """文字交互模式（跳过 Step 1-3）"""
        self._running = True
        print(f"\n💬 {config.app_name} - 文字模式")
        print("   支持: 天气查询、计算、翻译、闹钟、提醒、普通问答")
        print("   输入 'help' 查看示例，'clear' 清空对话，'q' 退出\n")

        while self._running:
            try:
                user_input = input("👤 您: ").strip()

                if not user_input:
                    continue
                if user_input.lower() in ("q", "quit", "exit"):
                    print("👋 再见！")
                    break
                if user_input.lower() == "help":
                    self._show_help()
                    continue
                if user_input.lower() == "clear":
                    if self.session_id:
                        self.agent.clear_session(self.session_id)
                    print("✅ 对话历史已清空\n")
                    continue
                if user_input.lower() == "tools":
                    self._show_tools()
                    continue
                if user_input.lower() == "info":
                    self._show_session_info()
                    continue

                self._process_and_respond(user_input)

            except KeyboardInterrupt:
                print("\n👋 再见！")
                break

    def _process_and_respond(self, user_text: str):
        """Step 4-11: 处理用户输入并响应"""
        print(f"\n📤 Step 4: 文本发送至后端服务: 「{user_text}」")

        # Step 5-9: Agent 处理
        response = self.agent.process(
            user_text,
            session_id=self.session_id,
            user_id="user_001",
        )

        # 保存 session_id（用于后续多轮对话）
        self.session_id = response.session_id

        # Step 10: 文字返回手机端
        print(f"\n📱 Step 10: 文字返回手机端")
        print(f"\n🤖 助手 [{response.task_type}]: {response.text_response}")

        if response.tool_results:
            print(f"   🔧 工具调用: {len(response.tool_results)} 次")

        print(f"   ⏱️  耗时: {response.latency_ms:.0f}ms | "
              f"意图: {response.intent} | 会话: {response.session_id}")

        # Step 11: TTS 语音播报
        print(f"\n🔊 Step 11: TTS 语音播报")
        self.tts.speak(response.text_response)
        print()

    def _show_help(self):
        examples = [
            ("天气查询", "今天北京天气怎么样？"),
            ("数学计算", "计算 1234 乘以 5678"),
            ("翻译", "翻译：人工智能改变世界"),
            ("设置闹钟", "帮我设置明天早上8点的闹钟"),
            ("设置提醒", "提醒我明天下午3点开会"),
            ("普通问答", "什么是量子计算？"),
            ("多轮对话", "（接上一条）能说得更简单一些吗？"),
        ]
        print("\n📚 示例命令:")
        for category, example in examples:
            print(f"  [{category}] {example}")
        print()

    def _show_tools(self):
        tools = self.agent.list_tools()
        print(f"\n🔧 可用工具 ({len(tools)} 个):")
        for t in tools:
            print(f"  - {t['name']}: {t['description']}")
        print()

    def _show_session_info(self):
        if not self.session_id:
            print("  暂无会话信息\n")
            return
        info = self.agent.get_session_info(self.session_id)
        if info:
            print(f"\n📊 会话信息: {info}\n")


# ─────────────────────────────────────────────────────────────────
# 快速测试：模拟完整工作流
# ─────────────────────────────────────────────────────────────────

def run_demo():
    """运行演示，展示完整工作流"""
    print("\n" + "=" * 70)
    print("  🤖 移动端 AI 语音助手 Agent - 完整工作流演示")
    print("=" * 70)

    assistant = VoiceAssistant()

    demo_inputs = [
        "今天北京天气怎么样",
        "帮我计算 1234 乘以 5678",
        "翻译：人工智能改变世界",
        "帮我设置明天早上8点的闹钟",
        "提醒我明天下午3点有个重要会议",
        "什么是机器学习？用简单的话解释一下",
        "刚才你说的机器学习，能举个生活中的例子吗？",  # 多轮对话
    ]

    print(f"\n▶ 将演示 {len(demo_inputs)} 个典型场景\n")

    for i, user_input in enumerate(demo_inputs, 1):
        print(f"\n{'─' * 60}")
        print(f"场景 {i}/{len(demo_inputs)}: 「{user_input}」")
        print("─" * 60)

        # 模拟 Step 1: 用户语音输入（这里直接用文字模拟）
        print(f"🎙️  Step 1-3: 语音输入 → ASR识别 → 「{user_input}」")

        assistant._process_and_respond(user_input)
        time.sleep(0.5)

    print("\n" + "=" * 70)
    print("  ✅ 演示完成！")
    print(f"  📊 会话ID: {assistant.session_id}")
    print("=" * 70 + "\n")


# ─────────────────────────────────────────────────────────────────
# CLI 入口
# ─────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="移动端 AI 语音助手 Agent",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
运行模式:
  demo    - 自动演示（无需用户输入）
  text    - 文字交互模式
  voice   - 语音交互模式（需要麦克风）
  server  - 启动 REST API 服务器
        """
    )
    parser.add_argument(
        "mode",
        nargs="?",
        default="demo",
        choices=["demo", "text", "voice", "server"],
        help="运行模式 (默认: demo)"
    )
    parser.add_argument("--host", default="0.0.0.0", help="服务器地址")
    parser.add_argument("--port", type=int, default=8000, help="服务器端口")
    parser.add_argument("--debug", action="store_true", help="调试模式")

    args = parser.parse_args()

    if args.mode == "demo":
        run_demo()

    elif args.mode == "text":
        assistant = VoiceAssistant()
        assistant.run_text_mode()

    elif args.mode == "voice":
        assistant = VoiceAssistant()
        assistant.run_voice_mode()

    elif args.mode == "server":
        config.server.host = args.host
        config.server.port = args.port
        config.server.debug = args.debug

        print(f"\n🚀 启动 API 服务器: http://{args.host}:{args.port}")
        print("   可用接口:")
        print(f"   GET  http://localhost:{args.port}/health")
        print(f"   POST http://localhost:{args.port}/api/chat")
        print(f"   POST http://localhost:{args.port}/api/voice/recognize")
        print(f"   POST http://localhost:{args.port}/api/voice/process")
        print(f"   POST http://localhost:{args.port}/api/tts")
        print(f"   GET  http://localhost:{args.port}/api/tools\n")

        # 动态导入避免循环依赖
        from server.app import app
        app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == "__main__":
    main()
