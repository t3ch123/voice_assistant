"""
移动端 AI 语音助手 Agent - 全局配置
"""
import os
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ASRConfig:
    """ASR 语音识别配置"""
    provider: str = "google"          # google / whisper / baidu / mock
    language: str = "zh-CN"
    sample_rate: int = 16000
    channels: int = 1
    chunk_size: int = 1024
    silence_threshold: int = 500      # 静音检测阈值 (毫秒)
    max_record_seconds: int = 30      # 最长录音时间
    energy_threshold: int = 300       # 声音能量阈值
    # Whisper 本地模型配置
    whisper_model: str = "base"       # tiny / base / small / medium / large
    # 百度 ASR 配置
    baidu_app_id: str = os.getenv("BAIDU_APP_ID", "")
    baidu_api_key: str = os.getenv("BAIDU_API_KEY", "")
    baidu_secret_key: str = os.getenv("BAIDU_SECRET_KEY", "")


@dataclass
class TTSConfig:
    """TTS 语音合成配置"""
    provider: str = "gtts"            # gtts / pyttsx3 / baidu / mock
    language: str = "zh"
    speed: float = 1.0                # 语速 (0.5 ~ 2.0)
    volume: float = 0.9               # 音量 (0.0 ~ 1.0)
    output_dir: str = "audio_cache"


@dataclass
class LLMConfig:
    """大语言模型配置"""
    provider: str = "openai"          # openai / anthropic / zhipu / mock
    model: str = "gpt-4o-mini"
    api_key: str = os.getenv("OPENAI_API_KEY", "")
    api_base: str = os.getenv("OPENAI_API_BASE", "https://api.openai.com/v1")
    max_tokens: int = 2048
    temperature: float = 0.7
    # Anthropic
    anthropic_api_key: str = os.getenv("ANTHROPIC_API_KEY", "")
    anthropic_model: str = "claude-3-haiku-20240307"
    # 智谱 AI
    zhipu_api_key: str = os.getenv("ZHIPU_API_KEY", "")
    zhipu_model: str = "glm-4-flash"
    timeout: int = 30


@dataclass
class AgentConfig:
    """Agent 配置"""
    max_context_turns: int = 20       # 最大上下文轮数
    max_tool_calls: int = 5           # 单次任务最大工具调用次数
    task_timeout: int = 60            # 任务超时时间 (秒)
    enable_streaming: bool = False    # 是否启用流式输出
    system_prompt: str = (
        "你是一个智能语音助手Agent。你能够理解用户意图，执行复杂任务，"
        "调用工具，并保持多轮对话上下文。请用简洁、自然的中文回复用户。"
        "如果需要执行工具，请明确说明你在做什么。"
    )


@dataclass
class ServerConfig:
    """后端服务配置"""
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = False
    reload: bool = False
    workers: int = 1
    cors_origins: list = field(default_factory=lambda: ["*"])
    max_request_size: int = 10 * 1024 * 1024  # 10MB


@dataclass
class AppConfig:
    """应用总配置"""
    app_name: str = "移动端AI语音助手Agent"
    version: str = "1.0.0"
    log_level: str = "INFO"
    log_file: str = "logs/assistant.log"

    asr: ASRConfig = field(default_factory=ASRConfig)
    tts: TTSConfig = field(default_factory=TTSConfig)
    llm: LLMConfig = field(default_factory=LLMConfig)
    agent: AgentConfig = field(default_factory=AgentConfig)
    server: ServerConfig = field(default_factory=ServerConfig)


# 全局配置实例
config = AppConfig()

# 根据环境变量自动切换 provider
if not config.llm.api_key and not config.llm.anthropic_api_key and not config.llm.zhipu_api_key:
    config.llm.provider = "mock"

if not config.asr.baidu_api_key:
    config.asr.provider = "mock"

if config.tts.provider == "gtts":
    try:
        import gtts
    except ImportError:
        config.tts.provider = "mock"
