"""
Step 4 & 10: 文本发送至后端服务 / 文字返回手机端
Flask REST API 后端服务
"""
import json
import os
import sys
import time
import base64
from typing import Optional

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from flask import Flask, request, jsonify, Response, stream_with_context
from flask_cors import CORS

from config import config
from modules.agent import Agent
from modules.asr import ASRManager
from modules.tts import TTSManager
from modules.logger import setup_logger

logger = setup_logger("server")

# ─────────────────────────────────────────────
# 初始化 Flask 应用
# ─────────────────────────────────────────────
app = Flask(__name__)
CORS(app, origins=config.server.cors_origins)

# 初始化核心组件
agent = Agent(config)
asr_manager = ASRManager(config)
tts_manager = TTSManager(config)


# ─────────────────────────────────────────────
# 健康检查
# ─────────────────────────────────────────────
@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status": "ok",
        "app": config.app_name,
        "version": config.version,
        "timestamp": time.time(),
        "llm_provider": config.llm.provider,
        "asr_provider": config.asr.provider,
        "tts_provider": config.tts.provider,
    })


# ─────────────────────────────────────────────
# Step 4: 文本消息接口（核心接口）
# POST /api/chat
# ─────────────────────────────────────────────
@app.route("/api/chat", methods=["POST"])
def chat():
    """
    接收文字消息，返回 Agent 回复
    请求体: { "text": "用户输入", "session_id": "可选", "user_id": "可选" }
    """
    data = request.get_json(silent=True) or {}
    user_text = data.get("text", "").strip()
    session_id = data.get("session_id")
    user_id = data.get("user_id", "default")

    if not user_text:
        return jsonify({"error": "text 字段不能为空"}), 400

    logger.info(f"[API] POST /api/chat | text=「{user_text}」 | session={session_id}")

    response = agent.process(user_text, session_id=session_id, user_id=user_id)

    # Step 10: 文字返回手机端
    return jsonify({
        "session_id": response.session_id,
        "text": response.text_response,     # Step 10: 返回文字
        "intent": response.intent,
        "task_type": response.task_type,
        "tool_results": response.tool_results,
        "success": response.success,
        "latency_ms": round(response.latency_ms, 2),
        "metadata": response.metadata,
    })


# ─────────────────────────────────────────────
# 语音输入接口
# POST /api/voice/recognize
# ─────────────────────────────────────────────
@app.route("/api/voice/recognize", methods=["POST"])
def voice_recognize():
    """
    接收音频文件，返回识别文字 (Step 3: ASR)
    支持 multipart/form-data (file) 或 JSON base64 (audio_base64)
    """
    # 方式1: 文件上传
    if "file" in request.files:
        audio_file = request.files["file"]
        tmp_path = f"/tmp/voice_{int(time.time())}.wav"
        audio_file.save(tmp_path)
        try:
            text = asr_manager.transcribe_file(tmp_path)
            os.unlink(tmp_path)
        except Exception as e:
            return jsonify({"error": str(e)}), 500
    # 方式2: Base64 编码音频
    elif request.is_json:
        data = request.get_json()
        audio_b64 = data.get("audio_base64", "")
        if not audio_b64:
            return jsonify({"error": "需要提供 file 或 audio_base64"}), 400
        audio_bytes = base64.b64decode(audio_b64)
        text = asr_manager.transcribe_bytes(audio_bytes)
    else:
        return jsonify({"error": "不支持的请求格式"}), 400

    return jsonify({"text": text, "success": bool(text)})


# ─────────────────────────────────────────────
# 语音输入 + 处理 + 语音输出（全流程接口）
# POST /api/voice/process
# ─────────────────────────────────────────────
@app.route("/api/voice/process", methods=["POST"])
def voice_process():
    """
    完整语音处理流程:
    音频 → ASR → Agent → TTS → 返回音频
    """
    session_id = request.form.get("session_id") or (request.get_json(silent=True) or {}).get("session_id")
    return_audio = request.args.get("return_audio", "false").lower() == "true"

    # Step 3: ASR 识别
    if "file" in request.files:
        audio_file = request.files["file"]
        tmp_path = f"/tmp/voice_in_{int(time.time())}.wav"
        audio_file.save(tmp_path)
        user_text = asr_manager.transcribe_file(tmp_path)
        os.unlink(tmp_path)
    else:
        data = request.get_json(silent=True) or {}
        user_text = data.get("text", "")
        session_id = session_id or data.get("session_id")

    if not user_text:
        return jsonify({"error": "无法识别音频或文字为空"}), 400

    # Step 5-9: Agent 处理
    response = agent.process(user_text, session_id=session_id)

    result = {
        "session_id": response.session_id,
        "asr_text": user_text,
        "text": response.text_response,
        "intent": response.intent,
        "task_type": response.task_type,
        "success": response.success,
        "latency_ms": round(response.latency_ms, 2),
    }

    # Step 11: TTS 合成（可选返回音频）
    if return_audio:
        audio_bytes = tts_manager.synthesize_to_bytes(response.text_response)
        result["audio_base64"] = base64.b64encode(audio_bytes).decode("utf-8")
        result["audio_format"] = "mp3"

    return jsonify(result)


# ─────────────────────────────────────────────
# TTS 接口
# POST /api/tts
# ─────────────────────────────────────────────
@app.route("/api/tts", methods=["POST"])
def text_to_speech():
    """将文字转换为语音，返回音频文件"""
    data = request.get_json(silent=True) or {}
    text = data.get("text", "").strip()
    if not text:
        return jsonify({"error": "text 不能为空"}), 400

    audio_bytes = tts_manager.synthesize_to_bytes(text)
    if not audio_bytes:
        return jsonify({"error": "TTS 合成失败"}), 500

    audio_b64 = base64.b64encode(audio_bytes).decode("utf-8")
    return jsonify({
        "audio_base64": audio_b64,
        "format": "mp3",
        "text": text,
        "success": True,
    })


# ─────────────────────────────────────────────
# 会话管理接口
# ─────────────────────────────────────────────
@app.route("/api/session/<session_id>", methods=["GET"])
def get_session(session_id: str):
    info = agent.get_session_info(session_id)
    if not info:
        return jsonify({"error": "会话不存在"}), 404
    return jsonify(info)


@app.route("/api/session/<session_id>/clear", methods=["POST"])
def clear_session(session_id: str):
    agent.clear_session(session_id)
    return jsonify({"message": f"会话 {session_id} 已清空", "success": True})


@app.route("/api/sessions", methods=["GET"])
def list_sessions():
    sessions = agent.context_manager.list_sessions()
    return jsonify({"sessions": sessions, "count": len(sessions)})


# ─────────────────────────────────────────────
# 工具接口
# ─────────────────────────────────────────────
@app.route("/api/tools", methods=["GET"])
def list_tools():
    tools = agent.list_tools()
    return jsonify({"tools": tools, "count": len(tools)})


@app.route("/api/tools/<tool_name>", methods=["POST"])
def call_tool(tool_name: str):
    """直接调用指定工具"""
    params = request.get_json(silent=True) or {}
    result = agent.tools.execute(tool_name, **params)
    return jsonify(result.to_dict())


# ─────────────────────────────────────────────
# 流式聊天（SSE）
# GET /api/chat/stream
# ─────────────────────────────────────────────
@app.route("/api/chat/stream", methods=["POST"])
def chat_stream():
    """流式响应（Server-Sent Events）"""
    data = request.get_json(silent=True) or {}
    user_text = data.get("text", "").strip()
    session_id = data.get("session_id")

    if not user_text:
        return jsonify({"error": "text 不能为空"}), 400

    session = agent.context_manager.get_or_create_session(session_id)
    from modules.context import MessageRole
    session.add_message(MessageRole.USER, user_text)
    messages = session.get_messages_for_llm(config.agent.system_prompt)
    messages.append({"role": "user", "content": user_text})

    def generate():
        full_text = ""
        try:
            for chunk in agent.llm.chat_stream(messages):
                full_text += chunk
                yield f"data: {json.dumps({'chunk': chunk, 'done': False}, ensure_ascii=False)}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'error': str(e), 'done': True}, ensure_ascii=False)}\n\n"
            return

        session.add_message(MessageRole.ASSISTANT, full_text)
        yield f"data: {json.dumps({'chunk': '', 'done': True, 'full_text': full_text}, ensure_ascii=False)}\n\n"

    return Response(
        stream_with_context(generate()),
        content_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ─────────────────────────────────────────────
# 错误处理
# ─────────────────────────────────────────────
@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "接口不存在", "code": 404}), 404


@app.errorhandler(500)
def internal_error(e):
    logger.error(f"服务器内部错误: {e}")
    return jsonify({"error": "服务器内部错误", "code": 500}), 500


@app.errorhandler(413)
def too_large(e):
    return jsonify({"error": "请求体过大", "code": 413}), 413


if __name__ == "__main__":
    logger.info(f"启动 Flask 服务: http://{config.server.host}:{config.server.port}")
    app.run(
        host=config.server.host,
        port=config.server.port,
        debug=config.server.debug,
    )
